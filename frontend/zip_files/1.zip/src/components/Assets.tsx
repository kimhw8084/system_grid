import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { AgGridReact } from 'ag-grid-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { AnimatePresence, motion } from 'framer-motion'
import ForceGraph2D from 'react-force-graph-2d'
import { createPortal } from 'react-dom'
import { AssetDetailsView } from './assets/AssetDetailsView'
import { WorkspaceShareHeader } from './shared/WorkspaceShareHeader'
import { WorkspaceEmptyState } from "./shared/OperationalWorkspacePrimitives";
import { Plus, Trash2, Cpu, Package, X, RefreshCcw, Search, Edit2, LayoutGrid, List, FileJson, Check, MoreVertical, Settings, Sliders, Globe, Eye, EyeOff, ArrowRightLeft, Tag, AlertCircle, Layers, Terminal, FileText, Clipboard, Filter, Calendar, Activity, Link as LinkIcon, Database, HardDrive, Cpu as CpuIcon, Box, Network, Server, ExternalLink, Share2, ZoomIn, ZoomOut, Maximize2, Minimize2, Shield, Zap, Save, Upload, RefreshCw, AlertTriangle, ChevronDown, ChevronRight, Book } from 'lucide-react'
import toast from 'react-hot-toast'
import { apiFetch } from "../api/apiClient"
import { BulkImportModal } from "./shared/BulkImportModal"
import { ConfigRegistryModal } from "./ConfigRegistry"
import { ConfirmationModal } from "./shared/ConfirmationModal"
import { ConnectionForensicsModal } from "./shared/ConnectionForensicsModal"
import { WorkspaceModal } from "./shared/WorkspaceModal"
import { ToolbarButton } from "./shared/LayoutPrimitives"
import { StyledSelect } from "./shared/StyledSelect"
import { ServiceDetailsView, ServiceForm } from "./ServiceRegistry"

const SharedServiceModals = ({ 
  activeDetails, 
  setActiveDetails, 
  activeEdit, 
  setActiveEdit, 
  options, 
  devices,
  onServiceUpdate
}: any) => {
  const queryClient = useQueryClient()
  const [isMaximized, setIsMaximized] = useState(false)
  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const url = `/api/v1/logical-services/${data.id}`
      const method = "PUT"
      const res = await apiFetch(url, { method, body: JSON.stringify(data) })
      return res.json()
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ["logical-services"] })
      queryClient.invalidateQueries({ queryKey: ["device-services"] })
      toast.success("Service Registry Updated")
      setActiveEdit(null)
      onServiceUpdate?.()
    },
    onError: (e: any) => toast.error(e.message)
  })

  return (
    <>
      <WorkspaceModal
        isOpen={!!activeEdit}
        onClose={() => setActiveEdit(null)}
        size="workspace"
        isMaximized={isMaximized}
        onMaximizeToggle={() => setIsMaximized(!isMaximized)}
        title="Modify Service Configuration"
        subtitle="Logical Service Identity & Environment"
        icon={<Layers size={20}/>}
        footerRight={
          <ToolbarButton onClick={() => setActiveEdit(null)}>Close</ToolbarButton>
        }
      >
        <div className="pt-6">
          <ServiceForm initialData={activeEdit} onSave={mutation.mutate} options={options} devices={devices} />
        </div>
      </WorkspaceModal>

      <WorkspaceModal
        isOpen={!!activeDetails}
        onClose={() => setActiveDetails(null)}
        size="workspace"
        isMaximized={isMaximized}
        onMaximizeToggle={() => setIsMaximized(!isMaximized)}
        title={activeDetails?.name || 'Service Details'}
        subtitle={`${activeDetails?.service_type} // ${activeDetails?.environment}`}
        icon={<Eye size={20}/>}
        footerRight={
          <ToolbarButton onClick={() => setActiveDetails(null)}>Close</ToolbarButton>
        }
      >
        <div className="pt-6">
          <ServiceDetailsView service={activeDetails} options={options} devices={devices} />
        </div>
      </WorkspaceModal>
    </>
  )
}

const CopyButton = ({ value, label }: { value: string, label?: string }) => {
  const [copied, setCopied] = useState(false);
  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(value);
    setCopied(true);
    toast.success(`${label || 'Value'} Copied`);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button onClick={handleCopy} className="p-1 hover:bg-white/10 rounded-lg transition-all text-slate-500 hover:text-blue-400">
      {copied ? <Check size={10} /> : <Clipboard size={10} />}
    </button>
  );
};

const getAssetConsoleUrl = (asset: any) => {
  if (asset?.management_url) {
    const trimmed = String(asset.management_url).trim()
    if (!trimmed) return null
    if (/^https?:\/\//i.test(trimmed)) return trimmed
    return `https://${trimmed}`
  }
  if (asset?.management_ip) return `https://${asset.management_ip}`
  return null
}

const SharedNetworkModals = ({
  activeEdit,
  setActiveEdit,
  options,
  devices,
  onUpdate
}: {
  activeEdit: any,
  setActiveEdit: (l: any) => void,
  options: any,
  devices: any,
  onUpdate: () => void
}) => {
  const queryClient = useQueryClient()
  const [connData, setConnData] = useState<any>({})
  const [isMaximized, setIsMaximized] = useState(false)

  useEffect(() => {
    if (activeEdit) {
      setConnData({
        ...activeEdit,
        device_a_id: activeEdit.source_device_id,
        device_b_id: activeEdit.target_device_id,
        port_a: activeEdit.source_port || activeEdit.port_a,
        port_b: activeEdit.target_port || activeEdit.port_b
      })
    }
  }, [activeEdit])

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiFetch(`/api/v1/networks/connections/${activeEdit.id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: () => {
      onUpdate()
      setActiveEdit(null)
      toast.success('Link Matrix Updated')
    },
    onError: (e: any) => toast.error(e.message)
  })

  return (
    <WorkspaceModal
      isOpen={!!activeEdit}
      onClose={() => setActiveEdit(null)}
      size="standard"
      isMaximized={isMaximized}
      onMaximizeToggle={() => setIsMaximized(!isMaximized)}
      title="Modify Connectivity"
      subtitle="Network Interface & Peer Parameters"
      icon={<LinkIcon size={20}/>}
      footerRight={
        <div className="flex items-center gap-3">
          <ToolbarButton onClick={() => setActiveEdit(null)}>Close</ToolbarButton>
          <ToolbarButton 
            onClick={() => {
              if(!connData.device_a_id || !connData.port_a || !connData.device_b_id || !connData.port_b) {
                return toast.error("Entity and Port mapping required")
              }
              mutation.mutate(connData)
            }} 
            disabled={mutation.isPending} 
            variant="primary"
          >
            {mutation.isPending ? <RefreshCw className="animate-spin mr-2" size={14} /> : <Check className="mr-2" size={14} />}
            <span>{mutation.isPending ? 'Syncing...' : 'Commit Changes'}</span>
          </ToolbarButton>
        </div>
      }
    >
      <div className="pt-6 grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <StyledSelect
            label="Source Entity *"
            value={connData.device_a_id}
            onChange={e => setConnData({...connData, device_a_id: e.target.value})}
            options={devices?.map((d: any) => ({ value: String(d.id), label: `${d.name} [${d.type}]` })) || []}
            placeholder="Select Registry Asset..."
          />
        </div>
        <div>
          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Source Port *</label>
          <input value={connData.port_a || ''} onChange={e => setConnData({...connData, port_a: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="eth0" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Src IP</label>
            <input value={connData.source_ip || ''} onChange={e => setConnData({...connData, source_ip: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="10.0.1.10" />
          </div>
          <div>
            <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Src VLAN</label>
            <input type="number" value={connData.source_vlan || ''} onChange={e => setConnData({...connData, source_vlan: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="100" />
          </div>
        </div>
        <div className="col-span-2">
          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Source MAC Address</label>
          <input value={connData.source_mac || ''} onChange={e => setConnData({...connData, source_mac: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="00:11:22:33:44:55" />
        </div>
        <StyledSelect
            label="Direction"
            value={connData.direction}
            onChange={e => setConnData({...connData, direction: e.target.value})}
            options={[{value: 'Bidirectional', label: 'Bidirectional'}, {value: 'Unidirectional', label: 'Unidirectional'}]}
        />
        <div className="col-span-2 border-t border-white/5 pt-4">
          <StyledSelect
            label="Peer Entity *"
            value={connData.device_b_id}
            onChange={e => setConnData({...connData, device_b_id: e.target.value})}
            options={devices?.filter((d:any) => d.id != connData.device_a_id).map((d: any) => ({ value: String(d.id), label: `${d.name} [${d.type}]` })) || []}
            placeholder="Select Registry Asset..."
          />
        </div>
        <div>
          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Peer Port *</label>
          <input value={connData.port_b || ''} onChange={e => setConnData({...connData, port_b: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="Te1/1/1" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Peer IP</label>
            <input value={connData.target_ip || ''} onChange={e => setConnData({...connData, target_ip: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="10.0.1.254" />
          </div>
          <div>
            <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Peer VLAN</label>
            <input type="number" value={connData.target_vlan || ''} onChange={e => setConnData({...connData, target_vlan: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="100" />
          </div>
        </div>
        <div className="col-span-2">
          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Peer MAC Address</label>
          <input value={connData.target_mac || ''} onChange={e => setConnData({...connData, target_mac: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="00:11:22:33:44:66" />
        </div>
        <StyledSelect
            label="Link Type *"
            value={connData.link_type}
            onChange={e => setConnData({...connData, link_type: e.target.value})}
            options={Array.isArray(options) && options.filter((o:any) => o.category === 'LinkPurpose').length > 0 
                ? options.filter((o:any) => o.category === 'LinkPurpose').map((p:any) => ({ value: p.value, label: p.label }))
                : ["Data", "Management", "Storage/iSCSI", "Backup", "vMotion", "Replication", "Heartbeat"].map(p => ({ value: p, label: p }))
            }
        />
        <div className="col-span-2">
          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Purpose / Description</label>
          <input value={connData.purpose || ''} onChange={e => setConnData({...connData, purpose: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" placeholder="e.g. Primary Data Uplink for Prod..." />
        </div>
        <div>
          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-1 block mb-1">Speed *</label>
          <input type="number" value={connData.speed_gbps} onChange={e => setConnData({...connData, speed_gbps: parseFloat(e.target.value) || 0})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
        </div>
        <StyledSelect
            label="Unit"
            value={connData.unit}
            onChange={e => setConnData({...connData, unit: e.target.value})}
            options={[{value: 'Gbps', label: 'Gbps'}, {value: 'Mbps', label: 'Mbps'}, {value: 'Tbps', label: 'Tbps'}]}
        />
      </div>
    </WorkspaceModal>
  )
}


const AssetServicesTable = ({ deviceId, onViewDetails, onEdit }: { deviceId: number, onViewDetails: (s: any) => void, onEdit: (s: any) => void }) => {
  const { data: services, isLoading } = useQuery({
    queryKey: ['device-services', deviceId],
    queryFn: async () => (await (await apiFetch(`/api/v1/logical-services?device_id=${deviceId}`)).json())
  })

  return (
    <div className="p-0 overflow-hidden">
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-12 text-slate-500">
          <RefreshCcw size={20} className="animate-spin mb-2" />
          <p className="text-[10px] font-bold uppercase">Loading services...</p>
        </div>
      )}
      {!isLoading && (<table className="w-full text-[10px]">
        <thead className="bg-white/5 border-b border-white/5">
          <tr>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Service Name</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Type</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Purpose</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Status</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Environment</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Installed</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Link</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {services?.map((s: any) => (
            <tr key={s.id} className="hover:bg-white/5 transition-colors">
              <td className="px-4 py-3 font-bold text-[10px] text-blue-400">{s.name}</td>
              <td className="px-4 py-3 text-slate-400 uppercase font-bold text-[10px]">{s.service_type}</td>
              <td className="px-4 py-3 text-slate-500 font-bold truncate max-w-[150px] text-[10px]">
                {s.purpose ? <span title={s.purpose}>{s.purpose}</span> : '-'}
              </td>
              <td className="px-4 py-3 text-center">
                 <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase border ${
                    s.status === 'Running' || s.status === 'Active' ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5' :
                    s.status === 'Stopped' ? 'text-slate-400 border-slate-500/20 bg-slate-500/5' :
                    s.status === 'Maintenance' ? 'text-amber-400 border-amber-500/20 bg-amber-500/5' :
                    'text-rose-400 border-rose-500/20 bg-rose-500/5'
                 }`}>{s.status}</span>
              </td>
              <td className="px-4 py-3 text-center text-slate-500 uppercase font-bold text-[10px]">{s.environment}</td>
              <td className="px-4 py-3 text-center text-blue-400/60 font-bold text-[10px]">
                {s.installation_date ? new Date(s.installation_date).toLocaleDateString() : '-'}
              </td>
              <td className="px-4 py-3 text-center">
                {s.documentation_link ? (
                  <a href={s.documentation_link} target="_blank" rel="noopener noreferrer" className="p-1 text-blue-400 hover:text-white transition-colors inline-block">
                    <ExternalLink size={12} />
                  </a>
                ) : '-'}
              </td>
              <td className="px-4 py-3 text-center">
                 <div className="flex items-center justify-center space-x-1">
                   <button
                     onClick={() => onViewDetails(s)}
                     className="p-1.5 bg-blue-600/10 text-blue-400 border border-blue-500/20 rounded-lg hover:bg-blue-600/20 transition-all flex items-center justify-center space-x-1"
                     title="View Service Forensics"
                   >
                     <List size={14}/>
                   </button>
                   <button
                     onClick={() => onEdit(s)}
                     className="p-1.5 bg-emerald-600/10 text-emerald-400 border border-emerald-500/20 rounded-lg hover:bg-emerald-600/20 transition-all flex items-center justify-center"
                     title="Edit Service Instance"
                   >
                     <Edit2 size={14}/>
                   </button>
                 </div>
              </td>
            </tr>
          ))}
          {!services?.length && !isLoading && (
            <tr><td colSpan={6} className="px-4 py-12 text-center text-slate-600 font-bold uppercase  tracking-widest">No logical services bound to this asset</td></tr>
          )}
        </tbody>
      </table>
      )}
    </div>
  )
}
const StatusBulkUpdateModal = ({ isOpen, onClose, onApply, options, count }: { isOpen: boolean, onClose: () => void, onApply: (status: string) => void, options: any[], count?: number }) => {
  const [selectedStatus, setSelectedStatus] = useState('')

  useEffect(() => {
    if (isOpen) setSelectedStatus('')
  }, [isOpen])

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md">
       <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="glass-panel w-[400px] p-10 rounded-lg border border-blue-500/30 space-y-6">
          <div>
            <h2 className="text-xl font-bold uppercase tracking-tighter text-blue-400 flex items-center space-x-3">
               <Tag size={24}/> <span>Update Status</span>
            </h2>
            {count && <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-2">Updating {count} asset{count !== 1 ? 's' : ''}</p>}
          </div>
          <StyledSelect
            label="Target Operational State"
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            options={STATUS_ITEMS}
            placeholder="Select Status..."
          />
          <div className="flex space-x-3 pt-2">
             <button onClick={onClose} className="flex-1 py-3 text-[10px] font-bold uppercase text-slate-500 hover:text-white transition-colors">Cancel</button>
             <button 
               disabled={!selectedStatus}
               onClick={() => onApply(selectedStatus)} 
               className="flex-2 py-3 bg-blue-600 disabled:opacity-50 text-white rounded-lg text-[10px] font-bold uppercase shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
             >
                Apply to Selection
             </button>
          </div>
       </motion.div>
    </div>
  )
}

const BulkEnvUpdateModal = ({ isOpen, onClose, onApply, options, count }: { isOpen: boolean, onClose: () => void, onApply: (env: string) => void, options: any[], count?: number }) => {
  const [selectedEnv, setSelectedEnv] = useState('')

  useEffect(() => {
    if (isOpen) setSelectedEnv('')
  }, [isOpen])

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md">
       <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="glass-panel w-[400px] p-10 rounded-lg border border-blue-500/30 space-y-6">
          <div>
            <h2 className="text-xl font-bold uppercase tracking-tighter text-blue-400 flex items-center space-x-3">
               <Globe size={24}/> <span>Update Environment</span>
            </h2>
            {count && <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-2">Updating {count} asset{count !== 1 ? 's' : ''}</p>}
          </div>
          <StyledSelect
            label="Target Environment"
            value={selectedEnv}
            onChange={e => setSelectedEnv(e.target.value)}
            options={ENVIRONMENT_ITEMS}
            placeholder="Select Environment..."
          />
          <div className="flex space-x-3 pt-2">
             <button onClick={onClose} className="flex-1 py-3 text-[10px] font-bold uppercase text-slate-500 hover:text-white transition-colors">Cancel</button>
             <button
               disabled={!selectedEnv}
               onClick={() => onApply(selectedEnv)}
               className="flex-1 py-3 bg-blue-600 disabled:opacity-50 text-white rounded-lg text-[10px] font-bold uppercase shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
             >
                Apply to Selection
             </button>
          </div>
       </motion.div>
    </div>
  )
}

const MetadataEditor = ({ value, onChange, onError }: { value: any, onChange: (v: any) => void, onError?: (err: string | null) => void }) => {
  const [mode, setMode] = useState<'table' | 'json'>('table')
  const [tableRows, setTableRows] = useState<{key: string, value: string}[]>([])
  const [jsonValue, setJsonValue] = useState('')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      const obj = typeof value === 'string' ? JSON.parse(value || '{}') : (value || {})
      setTableRows(Object.entries(obj).map(([k, v]) => ({ key: k, value: String(v) })))
      setJsonValue(JSON.stringify(obj, null, 2))
    } catch {
      setTableRows([])
      setJsonValue('')
      setError('Invalid metadata format')
      onError?.('Invalid metadata format')
    }
  }, [JSON.stringify(value), onError])

  const validateAndNotify = (rows: {key: string, value: string}[]) => {
    const obj: any = {}
    const keys = new Set()
    let hasDuplicate = false
    
    rows.forEach(r => {
      if (r.key) {
        if (keys.has(r.key)) hasDuplicate = true
        keys.add(r.key)
        obj[r.key] = r.value
      }
    })

    if (hasDuplicate) {
        setError("Duplicate keys detected")
        onError?.("Duplicate keys detected")
        return false
    } else {
        setError(null)
        onError?.(null)
        setJsonValue(JSON.stringify(obj, null, 2))
        onChange(obj)
        return true
    }
  }

  const syncFromJSON = (json: string) => {
    try {
        const obj = JSON.parse(json)
        const keys = Object.keys(obj)
        if (new Set(keys).size !== keys.length) {
            setError("Duplicate keys in JSON")
            onError?.("Duplicate keys in JSON")
            return false
        }
        const rows = Object.entries(obj).map(([k, v]) => ({ key: k, value: String(v) }))
        setTableRows(rows)
        setError(null)
        onError?.(null)
        onChange(obj)
        return true
    } catch (e) {
        setError("Invalid JSON format")
        onError?.("Invalid JSON format")
        return false
    }
  }

  return (
    <div className="bg-slate-900/50 rounded-lg border border-white/5 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/5">
         <div className="flex items-center space-x-3">
            <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500">Service Metadata</span>
            {error && <div className="flex items-center space-x-1 text-rose-500"><AlertCircle size={12} className="animate-pulse" /><span className="text-[8px] font-bold uppercase tracking-tighter">{error}</span></div>}
         </div>
         <div className="flex bg-black/40 rounded-lg p-1">
            <button onClick={() => setMode('table')} className={`px-2 py-1 rounded-lg transition-all ${mode === 'table' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}><List size={12}/></button>
            <button onClick={() => setMode('json')} className={`px-2 py-1 rounded-lg transition-all ${mode === 'json' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}><FileJson size={12}/></button>
         </div>
      </div>
      <div className="p-4 min-h-[120px]">
        {mode === 'table' ? (
          <div className="space-y-2">
            {tableRows.map((row, i) => (
              <div key={i} className="flex items-center space-x-2">
                <input value={row.key} onChange={e => {
                  const n = [...tableRows]; n[i].key = e.target.value; 
                  setTableRows(n); validateAndNotify(n);
                }} placeholder="Key" className={`flex-1 bg-black/40 border ${error?.includes('Duplicate') ? 'border-rose-500/50' : 'border-white/5'} rounded-lg px-3 py-1.5 text-[11px] outline-none focus:border-blue-500`} />
                <input value={row.value} onChange={e => {
                  const n = [...tableRows]; n[i].value = e.target.value; 
                  setTableRows(n); validateAndNotify(n);
                }} placeholder="Value" className="flex-[2] bg-black/40 border border-white/5 rounded-lg px-3 py-1.5 text-[11px] outline-none" />
                <button onClick={() => {
                    const n = tableRows.filter((_, idx) => idx !== i);
                    setTableRows(n); validateAndNotify(n);
                }} className="text-slate-600 hover:text-rose-400"><X size={14}/></button>
              </div>
            ))}
            <button onClick={() => {
                const n = [...tableRows, { key: '', value: '' }];
                setTableRows(n);
            }} className="text-[9px] font-bold text-blue-400 uppercase tracking-widest mt-2 hover:text-blue-300 transition-colors">+ Add Attribute Pair</button>
          </div>
        ) : (
          <textarea 
            value={jsonValue} 
            onChange={e => {
                setJsonValue(e.target.value);
                syncFromJSON(e.target.value);
            }} 
            className={`w-full h-32 bg-black/40 border ${error === 'Invalid JSON format' || error === 'Duplicate keys in JSON' ? 'border-rose-500/50' : 'border-white/5'} rounded-lg px-4 py-3 text-[11px] text-blue-300 outline-none`}
          />
        )}
      </div>
    </div>
  )
}

const MetadataViewer = ({ data }: { data: any }) => {
  let obj: any = {}
  try {
    obj = typeof data === 'string' ? JSON.parse(data || '{}') : (data || {})
  } catch {
    obj = {}
  }
  return (
    <div className="p-6 space-y-4">
      <h3 className="text-[10px] font-bold uppercase text-blue-400 tracking-[0.2em]">Metadata Inspection</h3>
      <div className="bg-slate-900/50 rounded-lg border border-white/5 overflow-hidden">
        <table className="w-full text-[10px]">
          <thead className="bg-white/5 border-b border-white/5">
            <tr>
              <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Key</th>
              <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Value</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {Object.entries(obj).map(([k, v]) => (
              <tr key={k} className="hover:bg-white/5 transition-colors">
                <td className="px-4 py-2 font-bold uppercase text-slate-400 text-[10px]">{k}</td>
                <td className="px-4 py-2 text-slate-200 font-bold text-[10px]">{String(v)}</td>
              </tr>
            ))}
            {Object.keys(obj).length === 0 && (
              <tr><td colSpan={2} className="px-4 py-8 text-center text-slate-600 font-bold uppercase ">No additional payload data</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

const MiniMonitoringTable = ({ deviceId }: { deviceId: number }) => {
  const { data: monitors, isLoading } = useQuery({
    queryKey: ['device-monitors', deviceId],
    queryFn: async () => (await apiFetch(`/api/v1/monitoring/?device_id=${deviceId}`)).json()
  })

  if (isLoading) return <div className="p-12 text-center text-[10px] font-bold uppercase animate-pulse text-slate-500">Retrieving Telemetry...</div>

  return (
    <div className="overflow-hidden">
      <table className="w-full text-[11px]">
        <thead className="bg-white/5 border-b border-white/5">
          <tr>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Category</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Title</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Status</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Severity</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Interval</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {monitors?.map((m: any) => (
            <tr key={m.id} className="hover:bg-white/5 transition-colors group">
              <td className="px-4 py-3 font-bold text-slate-400 uppercase">{m.category}</td>
              <td className="px-4 py-3 font-bold text-white group-hover:text-blue-400 transition-colors">{m.title}</td>
              <td className="px-4 py-3 text-center">
                 <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase border ${
                    m.status === 'Healthy' ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5' :
                    m.status === 'Degraded' ? 'text-amber-400 border-amber-500/20 bg-amber-500/5' :
                    'text-rose-400 border-rose-500/20 bg-rose-500/5'
                 }`}>{m.status}</span>
              </td>
              <td className="px-4 py-3 text-center">
                 <span className={`text-[10px] font-bold uppercase ${
                    m.severity === 'Critical' ? 'text-rose-500' :
                    m.severity === 'Warning' ? 'text-amber-500' :
                    'text-blue-400'
                 }`}>{m.severity}</span>
              </td>
              <td className="px-4 py-3 text-center font-mono text-slate-600">{m.check_interval}s</td>
            </tr>
          ))}
          {!monitors?.length && (
            <tr><td colSpan={5} className="px-4 py-12 text-center text-slate-600 font-bold uppercase tracking-widest">No active monitoring nodes deployed</td></tr>
          )}
        </tbody>
      </table>
    </div>
  )
}

const ConnectionMap = ({ deviceId, type, devices, onNodeClick }: { deviceId: number, type: 'dependency' | 'network', devices: any[], onNodeClick?: (d: any) => void }) => {
  const fgRef = React.useRef<any>();
  const [dimensions, setDimensions] = useState({ width: 500, height: 300 });
  const containerRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      setDimensions({
        width: containerRef.current.clientWidth,
        height: containerRef.current.clientHeight
      });
    }
  }, []);

  const { data: rels } = useQuery({ 
    queryKey: ['device-rel', deviceId], 
    queryFn: async () => (await apiFetch(`/api/v1/devices/${deviceId}/relationships`)).json(),
    enabled: type === 'dependency'
  })

  const { data: conns } = useQuery({ 
    queryKey: ['device-conns', deviceId], 
    queryFn: async () => (await apiFetch(`/api/v1/networks/connections?device_id=${deviceId}`)).json(),
    enabled: type === 'network'
  })

  const centerDevice = devices?.find(d => d.id === deviceId)
  
  const graphData = useMemo(() => {
    const nodes = [{ id: deviceId, name: centerDevice?.name || 'CENTRAL_NODE', isCenter: true, type: centerDevice?.type, fullData: centerDevice }]
    const links: any[] = []

    if (type === 'dependency' && rels) {
      rels.forEach((r: any) => {
        const isSource = r.source_device_id === deviceId
        const peerId = isSource ? r.target_device_id : r.source_device_id
        const peer = devices?.find(d => d.id === peerId)
        if (peer) {
          if (!nodes.find(n => n.id === peerId)) {
            nodes.push({ id: peerId, name: peer.name, isCenter: false, type: peer.type, fullData: peer })
          }
          links.push({ 
            source: isSource ? deviceId : peerId, 
            target: isSource ? peerId : deviceId, 
            label: r.relationship_type,
            role: isSource ? r.source_role : r.target_role,
            peerRole: isSource ? r.target_role : r.source_role
          })
        }
      })
    } else if (type === 'network' && conns) {
      conns.forEach((c: any) => {
        const isSource = c.src_device_id === deviceId
        const peerId = isSource ? c.dst_device_id : c.src_device_id
        const peer = devices?.find(d => d.id === peerId)
        if (peer) {
          if (!nodes.find(n => n.id === peerId)) {
            nodes.push({ id: peerId, name: peer.name, isCenter: false, type: peer.type, fullData: peer })
          }
          links.push({ 
            source: isSource ? deviceId : peerId, 
            target: isSource ? peerId : deviceId, 
            label: c.connection_type || c.link_type,
            details: `${c.src_port || c.source_port ? `P:${c.src_port || c.source_port}` : ''} ${c.dst_port || c.target_port ? `-> P:${c.dst_port || c.target_port}` : ''} [${c.vlan ? `V:${c.vlan}` : ''}]`
          })
        }
      })
    }

    return { nodes, links }
  }, [deviceId, rels, conns, devices, type, centerDevice])

  useEffect(() => {
    if (fgRef.current) {
      fgRef.current.d3Force('link').distance(150);
      fgRef.current.d3Force('charge').strength(-400);
      // Stabilize the engine to prevent jitter on every detail-view open
      fgRef.current.d3ReheatSimulation();
    }
  }, [graphData]);

  return (
    <div ref={containerRef} className="h-[260px] w-full relative bg-black/20 rounded-lg border border-white/5 overflow-hidden">
       {graphData.nodes.length <= 1 ? (
         <div className="h-full flex items-center justify-center text-[10px] font-bold uppercase text-slate-600 tracking-widest">
            No active {type} vectors identified
         </div>
       ) : (
         <ForceGraph2D
           ref={fgRef}
           graphData={graphData}
           height={dimensions.height}
           width={dimensions.width}
           nodeRelSize={4}
           nodeColor={n => (n as any).isCenter ? '#3b82f6' : '#f59e0b'}
           linkColor={() => 'rgba(255, 255, 255, 0.1)'}
           linkDirectionalArrowLength={6}
           linkDirectionalArrowRelPos={1}
           linkDirectionalParticles={2}
           linkDirectionalParticleSpeed={0.005}
           onNodeClick={(node: any) => onNodeClick?.(node.fullData)}
           onEngineStop={() => fgRef.current?.zoomToFit(400, 40)}
           linkCanvasObjectMode={() => 'after'}
           linkCanvasObject={(link: any, ctx, globalScale) => {
              const MAX_FONT_SIZE = 8;
              const start = link.source;
              const end = link.target;
              if (typeof start !== 'object' || typeof end !== 'object') return;

              const text = type === 'dependency' ? link.label : link.details || link.label;
              if (!text) return;
              
              const fontSize = Math.min(MAX_FONT_SIZE, 12 / globalScale);
              ctx.font = `900 ${fontSize}px Inter`;
              const textWidth = ctx.measureText(text.toUpperCase()).width;
              const padding = fontSize * 0.8;
              const bckgDimensions = [textWidth + padding, fontSize + padding/2];

              const relLink = { x: end.x - start.x, y: end.y - start.y };
              const textPos = { x: start.x + relLink.x * 0.5, y: start.y + relLink.y * 0.5 };

              let angle = Math.atan2(relLink.y, relLink.x);
              if (angle > Math.PI / 2 || angle < -Math.PI / 2) angle += Math.PI;

              ctx.save();
              ctx.translate(textPos.x, textPos.y);
              ctx.rotate(angle);
              
              ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
              ctx.fillRect(-bckgDimensions[0] / 2, -bckgDimensions[1] / 2, bckgDimensions[0], bckgDimensions[1]);

              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillStyle = type === 'dependency' ? '#818cf8' : '#34d399';
              ctx.fillText(text.toUpperCase(), 0, 0);
              ctx.restore();
           }}
           nodeCanvasObject={(node: any, ctx, globalScale) => {
             const label = (node.name || 'UNKNOWN').toUpperCase();
             const fontSize = 10/globalScale;
             ctx.font = `900 ${fontSize}px Inter`;

             ctx.shadowColor = node.isCenter ? 'rgba(59, 130, 246, 0.6)' : 'rgba(245, 158, 11, 0.4)';
             ctx.shadowBlur = 12 / globalScale;
             
             ctx.fillStyle = node.isCenter ? '#3b82f6' : '#f59e0b';
             ctx.beginPath(); 
             ctx.arc(node.x, node.y, node.isCenter ? 6 : 4, 0, 2 * Math.PI, false); 
             ctx.fill();

             ctx.shadowBlur = 0; 
             ctx.textAlign = 'center';
             ctx.textBaseline = 'top';
             ctx.fillStyle = '#f1f5f9';
             ctx.fillText(label, node.x, node.y + (node.isCenter ? 8 : 6));
           }}
         />
       )}
    </div>
  )
}

const AssetReportView = ({ assets, selectedId, onSelect, options, onEdit, onViewServiceDetails, onEditService, devices, onViewAssetDetails }: any) => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const [filter, setFilter] = useState({ name: '', system: '', type: '', status: '', env: '' })
  
  const filteredAssets = useMemo(() => {
    return assets?.filter((a: any) => {
      const matchName = a.name.toLowerCase().includes(filter.name.toLowerCase())
      const matchSystem = !filter.system || a.system === filter.system
      const matchType = !filter.type || a.type === filter.type
      const matchStatus = !filter.status || a.status === filter.status
      const matchEnv = !filter.env || a.environment === filter.env
      return matchName && matchSystem && matchType && matchStatus && matchEnv
    }) || []
  }, [assets, filter])

  const selectedAsset = useMemo(() => assets?.find((a: any) => a.id === selectedId), [assets, selectedId])

  useEffect(() => {
    if (!selectedId && filteredAssets.length > 0) {
      onSelect(filteredAssets[0].id)
    }
  }, [filteredAssets, selectedId, onSelect])

  const getOptions = (cat: string) => Array.isArray(options) ? options.filter((o: any) => o.category === cat) : []

  return (
    <div className="flex-1 flex overflow-hidden space-x-4">
      {/* Left Vertical List */}
      <div className="w-80 flex flex-col glass-panel rounded-lg overflow-hidden border-white/5">
        <div className="p-4 border-b border-white/5 space-y-3 bg-white/5">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              value={filter.name} 
              onChange={e => setFilter({ ...filter, name: e.target.value })} 
              placeholder="Search Assets..." 
              className="w-full bg-black/40 border border-white/5 rounded-lg pl-9 pr-4 py-2 text-[10px] font-bold outline-none focus:border-blue-500/50 transition-all" 
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <select value={filter.system} onChange={e => setFilter({ ...filter, system: e.target.value })} className="bg-black/40 border border-white/5 rounded-lg px-2 py-1.5 text-[9px] font-bold text-slate-400 outline-none">
              <option value="">All Systems</option>
              {getOptions('LogicalSystem').map((o: any) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <select value={filter.type} onChange={e => setFilter({ ...filter, type: e.target.value })} className="bg-black/40 border border-white/5 rounded-lg px-2 py-1.5 text-[9px] font-bold text-slate-400 outline-none">
              <option value="">All Types</option>
              {ASSET_TYPES.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <select value={filter.status} onChange={e => setFilter({ ...filter, status: e.target.value })} className="bg-black/40 border border-white/5 rounded-lg px-2 py-1.5 text-[9px] font-bold text-slate-400 outline-none">
              <option value="">All Statuses</option>
              {STATUS_ITEMS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <select value={filter.env} onChange={e => setFilter({ ...filter, env: e.target.value })} className="bg-black/40 border border-white/5 rounded-lg px-2 py-1.5 text-[9px] font-bold text-slate-400 outline-none">
              <option value="">All Envs</option>
              {ENVIRONMENT_ITEMS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
          {filteredAssets.map((a: any) => (
            <button
              key={a.id}
              onClick={() => onSelect(a.id)}
              className={`w-full flex flex-col p-3 rounded-lg transition-all text-left relative overflow-hidden group ${selectedId === a.id ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-white/5 text-slate-400'}`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-[11px] uppercase tracking-tighter truncate pr-2">{a.name}</span>
                <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-lg border ${
                  a.status === 'Active' ? 'bg-emerald-500/20 border-emerald-500/20 text-emerald-400' :
                  a.status === 'Maintenance' ? 'bg-amber-500/20 border-amber-500/20 text-amber-400' :
                  a.status === 'Failed' ? 'bg-rose-500/20 border-rose-500/20 text-rose-400' :
                  a.status === 'Reserved' ? 'bg-blue-500/20 border-blue-500/20 text-blue-400' :
                  a.status === 'Provisioning' ? 'bg-indigo-500/20 border-indigo-500/20 text-indigo-400' :
                  'bg-slate-500/10 border-white/5 text-slate-500'
                } ${selectedId === a.id ? 'border-white/40 text-white' : ''}`}>
                  {a.status}
                </span>
              </div>
              <div className="flex items-center space-x-2 text-[11px] font-bold opacity-60">
                <span>{a.system}</span>
                <span className="w-1 h-1 rounded-full bg-current opacity-30" />
                <span>{a.type}</span>
              </div>
              {selectedId === a.id && <motion.div layoutId="active-indicator" className="absolute left-0 top-0 bottom-0 w-1 bg-white" />}
            </button>
          ))}
          {!filteredAssets.length && (
            <WorkspaceEmptyState title="No matching assets" description="Adjust your filters or add new assets to the matrix." />
          )}
        </div>
      </div>

      {/* Right Report Content */}
      <div className="flex-1 glass-panel rounded-lg overflow-y-auto custom-scrollbar border-white/5 bg-[#0a0c14]/40 p-8">
        {selectedAsset ? (
          <div className="flex gap-8 items-start">
            {/* MAIN REPORT COLUMN */}
            <div className="flex-1 space-y-8">
                {/* Report Banner */}
                <div className="rounded-lg border border-blue-500/20 bg-gradient-to-r from-blue-600/10 to-transparent p-6">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-6">
                           <div className="bg-blue-600 p-3 rounded-lg text-white shadow-2xl shadow-blue-500/30 ring-4 ring-blue-500/10">
                              <Box size={40} />
                           </div>
                           <div className="grid grid-cols-3 gap-8">
                               <div className="flex flex-col">
                                  <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Operational State</span>
                                  <span className={`px-3 py-0.5 rounded-lg text-[10px] font-bold uppercase border w-fit ${
                                    selectedAsset.status === 'Active' ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5' :
                                    selectedAsset.status === 'Maintenance' ? 'text-amber-400 border-amber-500/20 bg-amber-500/5' :
                                    'text-rose-400 border-rose-500/20 bg-rose-500/5'
                                  }`}>{selectedAsset.status}</span>
                               </div>
                               <div className="flex flex-col">
                                  <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Primary IP</span>
                                  <span className="text-xl font-mono text-blue-400 font-bold tracking-tight">{selectedAsset.primary_ip || '---.---.---.---'}</span>
                               </div>
                               <div className="flex flex-col">
                                  <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Management IP</span>
                                  <span className="text-xl font-mono text-indigo-400 font-bold tracking-tight">{selectedAsset.management_ip || '---.---.---.---'}</span>
                               </div>
                           </div>
                        </div>
                    </div>
                </div>

                {/* Hardware & System */}
                <div className="space-y-4">
                   <div className="flex items-center space-x-3 border-b border-white/5 pb-2">
                      <CpuIcon size={16} className="text-amber-400" />
                      <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-400">Hardware & System Architecture</h3>
                   </div>
                   <div className="bg-black/20 p-8 rounded-lg border border-white/5 grid grid-cols-2 gap-y-8 gap-x-12">
                      <div>
                         <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-1">Platform Identity</p>
                         <p className="text-sm font-black text-white uppercase tracking-tight">{selectedAsset.manufacturer} {selectedAsset.model}</p>
                         <p className="text-[10px] font-mono text-slate-500 mt-1">SN: {selectedAsset.serial_number || 'UNKNOWN'}</p>
                      </div>
                      <div>
                         <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-1">Operating Environment</p>
                         <p className="text-sm font-black text-blue-400 uppercase tracking-tight">{selectedAsset.os_name} {selectedAsset.os_version}</p>
                         <p className="text-[9px] font-bold text-slate-500 mt-1 uppercase">Registry Depth: {selectedAsset.depth || 'Full'}</p>
                      </div>
                      <div className="col-span-2">
                         <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2">Resource Utilization Summary</p>
                         <div className="bg-black/40 p-4 rounded-lg border border-white/5 shadow-inner">
                            <p className="text-[11px] font-bold text-slate-300 uppercase leading-relaxed tracking-tight">{selectedAsset.hardware_summary || 'No hardware details registered for this unit.'}</p>
                         </div>
                      </div>
                   </div>
                </div>

                {/* Connection Maps Section */}
                <div className="space-y-4">
                   <div className="flex items-center space-x-3 border-b border-white/5 pb-2">
                      <Share2 size={16} className="text-indigo-400" />
                      <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-400">Vector Topologies & Interconnects</h3>
                   </div>
                   <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-3">
                         <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest text-center">Dependency Vector Map</p>
                         <ConnectionMap deviceId={selectedAsset.id} type="dependency" devices={devices} onNodeClick={onViewAssetDetails} />
                      </div>
                      <div className="space-y-3">
                         <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest text-center">Network Interconnect Map</p>
                         <ConnectionMap deviceId={selectedAsset.id} type="network" devices={devices} onNodeClick={onViewAssetDetails} />
                      </div>
                   </div>
                </div>

                {/* Logical Services & Telemetry */}
                <div className="grid grid-cols-2 gap-8">
                   <div className="space-y-4">
                      <div className="flex items-center space-x-3 border-b border-white/5 pb-2">
                         <Layers size={16} className="text-blue-400" />
                         <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-400">Hosted Logical Services</h3>
                      </div>
                      <div className="glass-panel rounded-lg overflow-hidden border-white/5 bg-black/20 min-h-[300px]">
                         <AssetServicesTable 
                           deviceId={selectedAsset.id} 
                           onViewDetails={onViewServiceDetails} 
                           onEdit={onEditService} 
                         />
                      </div>
                   </div>

                   <div className="space-y-4">
                      <div className="flex items-center space-x-3 border-b border-white/5 pb-2">
                         <Activity size={16} className="text-emerald-400" />
                         <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-400">Monitoring & Telemetry Nodes</h3>
                      </div>
                      <div className="glass-panel rounded-lg overflow-hidden border-white/5 bg-black/20 min-h-[300px]">
                         <MiniMonitoringTable deviceId={selectedAsset.id} />
                      </div>
                   </div>
                </div>
            </div>

            {/* SIDEBAR JUMP & META COLUMN */}
            <div className="w-80 shrink-0 space-y-6 sticky top-0">
                <div className="flex flex-col items-end space-y-2 mb-4">
                    <button onClick={() => onEdit(selectedAsset)} className="flex items-center space-x-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-blue-500 transition-all shadow-xl shadow-blue-600/20">
                        <Edit2 size={14}/> <span>Modify Config</span>
                    </button>
                    <div className="text-right">
                        <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Forensic Sync</p>
                        <p className="text-[9px] font-mono text-slate-400 font-bold">{new Date().toLocaleString()}</p>
                    </div>
                </div>

                {/* QUICK JUMPS */}
                <div className="glass-panel p-5 rounded-lg border-white/5 bg-white/5 space-y-3">
                   <p className="text-[9px] font-black uppercase tracking-[0.22em] text-slate-500 mb-2">Jump Actions</p>
                   <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => navigate(`/logs?target_table=devices&target_id=${selectedAsset.id}`)}
                          className="flex flex-col items-center justify-center p-3 rounded-lg border border-white/10 bg-white/[0.03] hover:bg-white/[0.08] transition-all group"
                        >
                          <Activity size={16} className="text-slate-500 group-hover:text-blue-400 mb-2" />
                          <span className="text-[8px] font-black uppercase tracking-widest text-slate-400">Audit</span>
                        </button>
                        <button
                          onClick={() => navigate(`/far?id=${selectedAsset.id}`)}
                          className="flex flex-col items-center justify-center p-3 rounded-lg border border-rose-500/20 bg-rose-500/10 hover:bg-rose-500/20 transition-all group"
                        >
                          <AlertTriangle size={16} className="text-rose-500 mb-2" />
                          <span className="text-[8px] font-black uppercase tracking-widest text-rose-400">FAR Risks</span>
                        </button>
                   </div>
                </div>

                {/* INCIDENT FLOW */}
                <div className="rounded-lg border border-white/10 bg-black/40 p-5 space-y-4 shadow-xl">
                    <p className="text-[9px] font-black uppercase tracking-[0.22em] text-emerald-400 flex items-center justify-between">
                       <span>Incident Flow</span>
                       <Activity size={12} />
                    </p>
                    <div className="space-y-2">
                        {/* Assuming monitoringItems is available or queried here as well */}
                        <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest italic text-center py-4">See Telemetry Tab for Active Nodes</p>
                    </div>
                </div>

                {/* PLACEMENT REGISTRY */}
                <div className="rounded-lg border border-white/10 bg-black/40 p-5 space-y-4 shadow-xl">
                    <p className="text-[9px] font-black uppercase tracking-[0.22em] text-indigo-400 flex items-center justify-between">
                       <span>Placement Registry</span>
                       <Database size={12} />
                    </p>
                    <div className="space-y-3">
                       <div className="flex justify-between items-center">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Site</span>
                          <span className="text-[10px] font-black text-white uppercase">{selectedAsset.site_name || 'UNPLACED'}</span>
                       </div>
                       <div className="flex justify-between items-center">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Rack</span>
                          <span className="text-[10px] font-black text-white uppercase">{selectedAsset.rack_name || 'N/A'}</span>
                       </div>
                       <div className="flex justify-between items-center">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">U-Pos</span>
                          <span className="text-[10px] font-black text-indigo-400 font-bold">{selectedAsset.u_start || '--'}U</span>
                       </div>
                    </div>
                </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-slate-600 space-y-4">
            <div className="p-6 bg-white/5 rounded-lg border border-white/10 opacity-20 animate-pulse">
               <FileText size={64} />
            </div>
            <p className="text-[10px] font-bold uppercase tracking-[0.5em]">Select Asset for Detailed Inspection</p>
          </div>
        )}
      </div>
    </div>
  )
}

const AssetComparisonView = ({ assets, selectedIds, onBack, onSync }: { assets: any[], selectedIds: number[], onBack: () => void, onSync: (key: string, value: any, ids: number[]) => void }) => {
  const selectedAssets = useMemo(() => 
    assets.filter(a => selectedIds.includes(a.id)),
    [assets, selectedIds]
  )
  const [pendingSync, setPendingSync] = useState<{ fieldKey: string, fieldLabel: string, value: any, sourceId: number } | null>(null)
  const [syncTargets, setSyncTargets] = useState<number[]>([])

  // Fetch hardware for all selected assets
  const hardwareQueries = useMemo(() => selectedIds.map(id => ({
    queryKey: ['device-hw', id],
    queryFn: async () => (await (await apiFetch(`/api/v1/devices/${id}/hardware`)).json())
  })), [selectedIds])

  const hardwareResults = useQuery({
    queryKey: ['bulk-hw', selectedIds],
    queryFn: async () => {
      const results = await Promise.all(selectedIds.map(async id => {
        const res = await apiFetch(`/api/v1/devices/${id}/hardware`)
        return { id, data: await res.json() }
      }))
      return results.reduce((acc, curr) => ({ ...acc, [curr.id]: curr.data }), {})
    }
  })

  const comparisonFields = [
    { label: 'Identity', fields: [
      { key: 'name', label: 'Hostname' },
      { key: 'role', label: 'Role' },
      { key: 'system', label: 'System' },
      { key: 'owner', label: 'Owner' },
      { key: 'business_unit', label: 'Business Unit' }
    ]},
    { label: 'Classification', fields: [
      { key: 'type', label: 'Type' },
      { key: 'status', label: 'Status' },
      { key: 'environment', label: 'Environment' }
    ]},
    { label: 'Connectivity', fields: [
      { key: 'primary_ip', label: 'Primary IP' },
      { key: 'management_ip', label: 'Mgmt IP' },
      { key: 'management_url', label: 'Mgmt URL' }
    ]},
    { label: 'Specifications', fields: [
      { key: 'manufacturer', label: 'Make' },
      { key: 'model', label: 'Model' },
      { key: 'os_name', label: 'OS Name' },
      { key: 'os_version', label: 'OS Version' },
      { key: 'hardware_summary', label: 'HW Summary' },
      { key: 'power_typical_w', label: 'Typical Power', format: (v: any) => v ? `${v}W` : '-' },
      { key: 'power_max_w', label: 'Max Power', format: (v: any) => v ? `${v}W` : '-' }
    ]},
    { label: 'Hardware Inventory', isHardware: true, categories: ['CPU', 'Memory', 'Disk', 'NIC', 'Card', 'PSU'] },
    { label: 'Logistics', fields: [
      { key: 'serial_number', label: 'Serial' },
      { key: 'asset_tag', label: 'Asset Tag' },
      { key: 'install_date', label: 'Install Date', format: (v: any) => v ? new Date(v).toLocaleDateString() : '-' },
      { key: 'warranty_end', label: 'Warranty End', format: (v: any) => v ? new Date(v).toLocaleDateString() : '-' },
      { key: 'hardware_age', label: 'HW Age' }
    ]}
  ]

  const renderHardwareRow = (category: string) => {
    const values = selectedAssets.map(asset => {
      const hwList = (hardwareResults.data as any)?.[asset.id] || []
      return JSON.stringify(hwList.filter((h: any) => h.category === category).map((h: any) => ({ n: h.name, c: h.count })))
    })
    const isMismatch = new Set(values).size > 1

    return (
      <tr key={category} className={`hover:bg-white/[0.02] transition-colors group ${isMismatch ? 'bg-rose-500/5' : ''}`}>
        <td className="p-4 px-6 border-r border-white/5">
          <div className={`text-[10px] font-bold uppercase tracking-tight group-hover:text-white transition-colors ${isMismatch ? 'text-rose-400 font-black' : 'text-slate-400'}`}>
            {category}
          </div>
        </td>
        {selectedAssets.map(asset => {
          const hwList = (hardwareResults.data as any)?.[asset.id] || []
          const comps = hwList.filter((h: any) => h.category === category)
          return (
            <td key={`${asset.id}-${category}`} className="p-4 px-6 border-l border-white/5">
              <div className="space-y-1">
                {comps.length > 0 ? comps.map((c: any, i: number) => (
                  <div key={i} className="text-[10px] leading-tight">
                    <span className="text-white font-bold">{c.count}x</span> <span className="text-slate-300">{c.name}</span>
                    <div className="text-[8px] text-slate-500 font-bold uppercase tracking-tighter">{c.specs}</div>
                  </div>
                )) : <span className="text-slate-600 font-bold uppercase text-[9px]">None</span>}
              </div>
            </td>
          )
        })}
      </tr>
    )
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-[#020617] p-8 animate-in fade-in duration-500 overflow-hidden">
       <div className="flex items-center justify-between mb-8 shrink-0">
          <div className="flex items-center space-x-6">
             <button onClick={onBack} className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-slate-400 hover:text-white transition-all">
                <ArrowRightLeft className="rotate-180" size={20} />
             </button>
             <div>
                <h1 className="text-3xl font-bold uppercase tracking-tighter text-white">System <span className="text-blue-500">Matrix Comparison</span></h1>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Comparative Analysis of {selectedAssets.length} Infrastructure Assets</p>
             </div>
          </div>
          <button onClick={onBack} className="p-3 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-lg text-rose-500 transition-all">
             <X size={24} />
          </button>
       </div>

       <div className="flex-1 overflow-auto custom-scrollbar glass-panel rounded-lg border border-white/5 bg-slate-900/20 shadow-2xl">
          <table className="w-full text-left border-collapse min-w-[800px]">
             <thead className="sticky top-0 z-10">
                <tr>
                   <th className="p-6 bg-slate-950 border-b border-white/5 w-64 shrink-0">
                      <div className="text-[10px] font-black uppercase tracking-widest text-slate-500">Comparison Vector</div>
                   </th>
                   {selectedAssets.map(asset => (
                      <th key={asset.id} className="p-6 bg-slate-950 border-b border-white/5 border-l border-white/5 min-w-[250px]">
                         <div className="flex flex-col">
                            <span className="text-blue-400 text-lg font-bold uppercase tracking-tight leading-none mb-1">{asset.name}</span>
                            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{asset.system} · {asset.type}</span>
                         </div>
                      </th>
                   ))}
                </tr>
             </thead>
             <tbody className="divide-y divide-white/5">
                {comparisonFields.map(section => (
                   <React.Fragment key={section.label}>
                      <tr className="bg-indigo-600/5">
                         <td colSpan={selectedAssets.length + 1} className="px-6 py-2.5 text-[9px] font-black uppercase tracking-widest text-indigo-400 border-y border-white/5">
                            {section.label}
                         </td>
                      </tr>
                      {section.isHardware ? (
                        section.categories?.map(cat => renderHardwareRow(cat))
                      ) : (
                        section.fields?.map(field => {
                          const values = selectedAssets.map(a => a[field.key])
                          const isMismatch = new Set(values).size > 1
                          return (
                            <tr key={field.key} className={`hover:bg-white/[0.02] transition-colors group ${isMismatch ? 'bg-rose-500/5' : ''}`}>
                                <td className="p-4 px-6 border-r border-white/5">
                                  <div className={`text-[10px] font-bold uppercase tracking-tight group-hover:text-white transition-colors ${isMismatch ? 'text-rose-400 font-black' : 'text-slate-400'}`}>
                                      {field.label}
                                  </div>
                                </td>
                                {selectedAssets.map(asset => (
                                  <td key={`${asset.id}-${field.key}`} className="p-4 px-6 border-l border-white/5 relative group/cell">
                                      <div className={`text-[11px] font-bold ${field.key === 'status' ? (
                                        asset.status === 'Active' ? 'text-emerald-400' : 
                                        asset.status === 'Maintenance' ? 'text-amber-400' :
                                        asset.status === 'Failed' ? 'text-rose-400' : 'text-slate-300'
                                      ) : isMismatch ? 'text-white' : 'text-slate-300'}`}>
                                        {field.format ? field.format(asset[field.key]) : (asset[field.key] || '-')}
                                      </div>

                                      {isMismatch && (
                                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                                          {!['name', 'serial_number', 'asset_tag', 'id', 'primary_ip', 'management_ip'].includes(field.key) ? (
                                            <button 
                                              onClick={() => {
                                                setPendingSync({
                                                  fieldKey: field.key,
                                                  fieldLabel: field.label,
                                                  value: asset[field.key],
                                                  sourceId: asset.id
                                                })
                                                setSyncTargets(selectedAssets.filter(a => a.id !== asset.id).map(a => a.id))
                                              }}
                                              className="p-1.5 bg-blue-600 text-white rounded-lg shadow-lg hover:scale-110 active:scale-95 transition-all"
                                              title={`Sync all to this ${field.label}`}
                                            >
                                              <RefreshCw size={10} />
                                            </button>
                                          ) : (
                                            <div className="p-1.5 bg-slate-800 text-slate-500 rounded-lg cursor-not-allowed" title="Unique Identifier: Sync Disabled">
                                              <Shield size={10} />
                                            </div>
                                          )}
                                        </div>
                                      )}
                                  </td>
                                ))}
                            </tr>
                          )
                        })
                      )}
                   </React.Fragment>
                ))}
             </tbody>
          </table>
	          {hardwareResults.isLoading && (
	            <div className="p-20 flex flex-col items-center justify-center text-slate-500 space-y-4">
	               <RefreshCcw size={24} className="animate-spin text-blue-500" />
	               <p className="text-[10px] font-bold uppercase tracking-widest">Hydrating Hardware Registry...</p>
	            </div>
	          )}
	       </div>
         <AnimatePresence>
           {pendingSync && (
             <motion.div
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               className="fixed inset-0 z-[120] flex items-center justify-center bg-black/70 backdrop-blur-md p-6"
             >
               <motion.div
                 initial={{ scale: 0.96, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 exit={{ scale: 0.96, opacity: 0 }}
                 className="w-full max-w-2xl rounded-lg border border-white/10 bg-slate-950 p-6 shadow-2xl"
               >
                 <div className="flex items-start justify-between gap-4">
                   <div>
                     <p className="text-[9px] font-black uppercase tracking-[0.22em] text-blue-400">Sync Preview</p>
                     <h3 className="mt-2 text-xl font-black uppercase tracking-tight text-white">{pendingSync.fieldLabel}</h3>
                     <p className="mt-1 text-[10px] font-bold uppercase tracking-widest text-slate-500">
                       Source value: {String(pendingSync.value || '-')}
                     </p>
                   </div>
                   <button onClick={() => setPendingSync(null)} className="text-slate-500 hover:text-white transition-colors">
                     <X size={18} />
                   </button>
                 </div>

                 <div className="mt-5 rounded-lg border border-white/5 bg-black/30 p-4">
                   <p className="mb-3 text-[9px] font-black uppercase tracking-[0.2em] text-slate-500">Apply To Selected Targets</p>
                   <div className="space-y-2">
                     {selectedAssets.filter(asset => asset.id !== pendingSync.sourceId).map(asset => (
                       <label key={asset.id} className="flex items-center justify-between rounded-lg border border-white/5 bg-white/[0.03] px-4 py-3">
                         <div>
                           <p className="text-[10px] font-bold uppercase text-slate-200">{asset.name}</p>
                           <p className="text-[9px] font-bold uppercase tracking-widest text-slate-500">
                             Current: {String(asset[pendingSync.fieldKey] || '-')}
                           </p>
                         </div>
                         <input
                           type="checkbox"
                           checked={syncTargets.includes(asset.id)}
                           onChange={(e) => {
                             setSyncTargets(prev => e.target.checked ? [...prev, asset.id] : prev.filter(id => id !== asset.id))
                           }}
                           className="h-4 w-4 accent-blue-500"
                         />
                       </label>
                     ))}
                   </div>
                 </div>

                 <div className="mt-5 flex items-center justify-between">
                   <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
                     {syncTargets.length} target asset{syncTargets.length === 1 ? '' : 's'} selected
                   </p>
                   <div className="flex items-center gap-2">
                     <button onClick={() => setPendingSync(null)} className="rounded-lg px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-white">
                       Cancel
                     </button>
                     <button
                       disabled={syncTargets.length === 0}
                       onClick={() => {
                         onSync(pendingSync.fieldKey, pendingSync.value, syncTargets)
                         setPendingSync(null)
                       }}
                       className="rounded-lg bg-blue-600 px-5 py-2 text-[10px] font-bold uppercase tracking-widest text-white shadow-lg shadow-blue-500/20 disabled:opacity-30"
                     >
                       Apply Sync
                     </button>
                   </div>
                 </div>
               </motion.div>
             </motion.div>
           )}
         </AnimatePresence>
	    </div>
	  )
	}

const AssetInsightBar = ({ assets }: any) => {
  const insights = useMemo(() => {
    if (!assets?.length) return null
    const critical = assets.filter((a: any) => a.status === 'Critical' || a.status === 'Down' || a.status === 'Failed').length
    const systems = [...new Set(assets.map((a: any) => a.system))].filter(Boolean).length
    const recent = assets.filter((a: any) => {
      const updated = new Date(a.updated_at)
      const diff = new Date().getTime() - updated.getTime()
      return diff < 86400000 // 24 hours
    }).length

    return { critical, systems, recent }
  }, [assets])

  if (!insights) return null

  return (
    <div className="grid grid-cols-4 gap-6 mb-8 animate-in fade-in slide-in-from-top-4 duration-700">
       <div className="bg-black/40 border border-white/5 p-6 rounded-lg backdrop-blur-xl shadow-xl group hover:border-rose-500/20 transition-all">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2 group-hover:text-rose-400 transition-colors">Operational Health</p>
          <div className="flex items-center gap-4">
             <div className={`w-3 h-3 rounded-full ${insights.critical > 0 ? 'bg-rose-500 animate-pulse shadow-[0_0_12px_rgba(244,63,94,0.5)]' : 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]'}`} />
             <h4 className="text-2xl font-black text-white tracking-tighter">{insights.critical > 0 ? `${insights.critical} Critical Alerts` : 'System Nominal'}</h4>
          </div>
       </div>
       <div className="bg-black/40 border border-white/5 p-6 rounded-lg backdrop-blur-xl shadow-xl group hover:border-blue-500/20 transition-all">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2 group-hover:text-blue-400 transition-colors">Ecosystem Breadth</p>
          <h4 className="text-2xl font-black text-blue-400 tracking-tighter">{insights.systems} Active Systems</h4>
       </div>
       <div className="bg-black/40 border border-white/5 p-6 rounded-lg backdrop-blur-xl shadow-xl group hover:border-emerald-500/20 transition-all">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2 group-hover:text-emerald-400 transition-colors">Human Activity</p>
          <h4 className="text-2xl font-black text-emerald-400 tracking-tighter">{insights.recent} Updates (24H)</h4>
       </div>
       <div className="bg-blue-600/10 border border-blue-500/20 p-6 rounded-lg backdrop-blur-xl shadow-xl flex items-center justify-between group hover:bg-blue-600/20 transition-all">
          <div>
             <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] mb-1">Registry Density</p>
             <h4 className="text-2xl font-black text-white tracking-tighter">{assets.length} Global Nodes</h4>
          </div>
          <Server size={28} className="text-blue-500 opacity-20 group-hover:opacity-100 group-hover:scale-110 transition-all" />
       </div>
    </div>
  )
}

export default function Assets() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [showImportModal, setShowImportModal] = useState(false)
  const [showBulkMenu, setShowBulkMenu] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedAssetId, setSelectedAssetId] = useState<number | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'report' | 'map' | 'compare'>('grid')
  const [selectedIds, setSelectedIds] = useState<number[]>([])
  const [showStyleLab, setShowStyleLab] = useState(false)
  const [showColumnPicker, setShowColumnPicker] = useState(false)
  const [showConfig, setShowConfig] = useState(false)
  const [isBulkStatusOpen, setIsBulkStatusOpen] = useState(false)
  const [isBulkEnvOpen, setIsBulkEnvOpen] = useState(false)
  const [isMaximized, setIsMaximized] = useState(false)
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([])
  const [fontSize] = useState(10)
  const [rowDensity] = useState(16)
  const [confirmModal, setConfirmModal] = useState<any>({ isOpen: false, title: '', message: '', onConfirm: () => {} })
  const [searchParams, setSearchParams] = useSearchParams()
  const gridRef = React.useRef<any>(null)
  const [gridApi, setGridApi] = useState<any>(null)
  const [gridColumnApi, setGridColumnApi] = useState<any>(null)
  
  const idParam = searchParams.get('id')
  const searchParam = searchParams.get('search')
  const statusParam = searchParams.get('status')

  const [quickLookId, setQuickLookId] = useState<number | null>(null)

  const { data: allEntities, isLoading: isEntitiesLoading } = useQuery({
    queryKey: ['external-entities', { include_deleted: true }],
    queryFn: async () => (await (await apiFetch('/api/v1/intelligence/entities?include_deleted=true')).json())
  })

  const [activeModal, setActiveModal] = useState<any>(null)
  const [activeDetails, setActiveDetails] = useState<any>(null)

  // --- Synchronization Hooks ---
  useEffect(() => {
    if (allEntities && idParam && !activeDetails) {
      const entity = allEntities.find((e: any) => String(e.id) === idParam)
      if (entity) setActiveDetails(entity)
    }
  }, [allEntities, idParam, activeDetails])
  const [activeServiceDetails, setActiveServiceDetails] = useState<any>(null)
  const [activeServiceEdit, setActiveServiceEdit] = useState<any>(null)
  const [selectedConnection, setSelectedConnection] = useState<any>(null)
  const [activeNetworkEdit, setActiveNetworkEdit] = useState<any>(null)
  const [activeLens, setActiveLens] = useState<'all' | 'mine' | 'team' | 'unowned' | 'degraded' | 'at_risk' | 'needs_docs'>('all')
  const [activeTab, setActiveTab] = useState<'inventory' | 'deleted'>('inventory')
  const [compareSnapshotIds, setCompareSnapshotIds] = useState<number[]>([])

  const openConfirm = (title: string, message: string, onConfirm: () => void, variant: any = 'danger') => {
    setConfirmModal({ isOpen: true, title, message, onConfirm, variant })
  }

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (showBulkMenu && !target.closest('.bulk-menu-container')) {
        setShowBulkMenu(false)
      }
    }
    if (showBulkMenu) {
      document.addEventListener('click', handleClickOutside)
      return () => document.removeEventListener('click', handleClickOutside)
    }
  }, [showBulkMenu])

  const { data: options } = useQuery({ queryKey: ['settings-options'], queryFn: async () => (await (await apiFetch('/api/v1/settings/options')).json()) })
  const { data: userProfile } = useQuery({
    queryKey: ['asset-user-profile'],
    queryFn: async () => (await apiFetch('/api/v1/settings/user/profile')).json()
  })
  const { data: devices, isLoading } = useQuery({
    queryKey: ['devices'],
    queryFn: async () => (await (await apiFetch('/api/v1/devices?include_deleted=true')).json())
  })

  useEffect(() => {
    if (searchParam) {
      setSearchTerm(searchParam)
    }
  }, [searchParam])

  useEffect(() => {
    if (!idParam || !devices) return

    const targetId = Number(idParam)
    if (!Number.isFinite(targetId)) return

    const asset = devices.find((a: any) => a.id === targetId)
    if (!asset) return

    setSelectedAssetId(targetId)
    setActiveTab(asset.is_deleted ? 'deleted' : 'inventory')
    setActiveLens('all')
    setViewMode('grid')
    if (!searchParam) setSearchTerm(asset.name)
  }, [idParam, devices, searchParam])

  useEffect(() => {
    const api = gridRef.current?.api
    if (!api) return
    if (!statusParam) {
      api.setFilterModel(null)
      return
    }
    api.setFilterModel({
      status: { filterType: 'text', type: 'equals', filter: statusParam }
    })
  }, [statusParam, devices, activeTab, activeLens, searchTerm])

  const { inventoryAssets, deletedAssets } = useMemo(() => {
    if (!devices) return { inventoryAssets: [], deletedAssets: [] }
    return {
      inventoryAssets: devices.filter((a: any) => !a.is_deleted),
      deletedAssets: devices.filter((a: any) => a.is_deleted)
    }
  }, [devices])

  const assets = activeTab === 'inventory' ? inventoryAssets : deletedAssets

  const displayedAssets = useMemo(() => {
    const normalize = (value: any) => String(value || '').trim().toLowerCase()
    const me = normalize(userProfile?.full_name || userProfile?.username)
    const team = normalize(userProfile?.team)
    const department = normalize(userProfile?.department)

    return assets.filter((asset: any) => {
      const owner = normalize(asset.owner)
      const businessUnit = normalize(asset.business_unit)
      const hasOwner = owner.length > 0
      const isMine = !!me && (owner === me || owner === normalize(userProfile?.username))
      const isTeam = !!team && (
        businessUnit === team ||
        owner.includes(team) ||
        (!!department && (businessUnit === department || owner.includes(department)))
      )
      const isDegraded = asset.open_incident_count > 0 || ['Maintenance', 'Offline', 'Failed'].includes(asset.status)
      const isAtRisk = isDegraded || !asset.management_ip || !asset.primary_ip || !asset.owner
      const needsDocs = !asset.owner || !asset.asset_tag || !asset.serial_number || !asset.management_ip

      switch (activeLens) {
        case 'mine':
          return isMine
        case 'team':
          return isTeam
        case 'unowned':
          return !hasOwner
        case 'degraded':
          return isDegraded
        case 'at_risk':
          return isAtRisk
        case 'needs_docs':
          return needsDocs
        default:
          return true
      }
    })
  }, [assets, activeLens, userProfile])

  const visibleAssets = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()
    if (!term) return displayedAssets

    const fields = [
      'name',
      'system',
      'type',
      'status',
      'environment',
      'owner',
      'asset_tag',
      'serial_number',
      'model',
      'manufacturer',
      'primary_ip',
      'management_ip',
      'management_url'
    ]

    return displayedAssets.filter((asset: any) =>
      fields.some((field) => String(asset?.[field] || '').toLowerCase().includes(term))
    )
  }, [displayedAssets, searchTerm])

  const compareCandidateIds = useMemo(() => visibleAssets.map((asset: any) => asset.id), [visibleAssets])
  const compareAssets = useMemo(
    () => assets.filter((asset: any) => compareSnapshotIds.includes(asset.id)),
    [assets, compareSnapshotIds]
  )

  useEffect(() => {
    setSelectedIds((current) => current.filter((id) => visibleAssets.some((asset: any) => asset.id === id)))
  }, [visibleAssets])

  useEffect(() => {
    if (viewMode === 'compare' && compareSnapshotIds.length === 0) {
      setViewMode('grid')
    }
  }, [viewMode, compareSnapshotIds])

  useEffect(() => {
    if (viewMode !== 'grid' || !gridApi || !selectedAssetId) return

    requestAnimationFrame(() => {
      gridApi.forEachNode((node: any) => {
        const isTarget = node.data?.id === selectedAssetId
        node.setSelected(isTarget)
        if (isTarget) {
          gridApi.ensureNodeVisible(node, 'middle')
        }
      })
    })
  }, [viewMode, selectedAssetId, visibleAssets, searchTerm, gridApi])

  // Only fetch full fabric map data when explicitly requested or in Map View
  const { data: allConnections } = useQuery({ 
    queryKey: ['connections-map-all'], 
    queryFn: async () => (await (await apiFetch('/api/v1/networks/connections')).json()),
    enabled: viewMode === 'map'
  })

  const { data: allRelationships } = useQuery({
    queryKey: ['all-relationships'],
    queryFn: async () => (await (await apiFetch('/api/v1/devices/relationships/all')).json()),
    enabled: viewMode === 'map'
  })

  const mutation = useMutation({
    mutationFn: async ({ data }: any) => {
      const url = data.id ? `/api/v1/devices/${data.id}` : `/api/v1/devices`
      const method = data.id ? 'PUT' : 'POST'
      try {
        const res = await apiFetch(url, { method, body: JSON.stringify(data) })
        return res.json()
      } catch (e: any) {
        if (e.message.includes('409') || e.message.includes('DUPLICATE')) {
          throw new Error('DUPLICATE_HOSTNAME')
        }
        throw e
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['devices'] })
      queryClient.invalidateQueries({ queryKey: ['racks-all'] })
      toast.success('System Registry Updated')
      setActiveModal(null)
    },
    onError: (e: any) => {
      if (e.message === 'DUPLICATE_HOSTNAME') toast.error('ERROR: Hostname already exists in registry')
      else toast.error(e.message)
    }
  })

  const bulkMutation = useMutation({
    mutationFn: async ({ action, payload = {}, ids: overrideIds }: any) => {
      const idsToUse = overrideIds ?? selectedIds
      const res = await apiFetch('/api/v1/devices/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ ids: idsToUse, action, payload })
      })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: (data: any, variables: any) => {
      queryClient.invalidateQueries({ queryKey: ['devices'] })
      queryClient.invalidateQueries({ queryKey: ['racks-all'] })
      if (viewMode !== 'compare') {
        setSelectedIds([])
      }
      setShowBulkMenu(false)
      setIsBulkStatusOpen(false)
      if (variables.action === 'restore') {
        if (data.conflicts?.length > 0) {
            toast.error(`Restored ${data.restored.length} assets. ${data.conflicts.length} failed due to hostname conflict.`)
        } else {
            toast.success(`Restored ${data.restored.length} assets successfully.`)
        }
      } else {
        toast.success('Bulk Operation Complete')
      }
    },
    onError: (e: any) => toast.error(`Operation failed: ${e.message}`)
  })

  const columnDefs = useMemo(() => [
    { 
      headerName: "", 
      width: 50,
      minWidth: 50,
      maxWidth: 50,
      checkboxSelection: true, 
      headerCheckboxSelection: true, 
      pinned: 'left', 
      cellClass: 'flex items-center justify-center border-r border-white/5 pl-2', 
      headerClass: 'flex items-center justify-center border-r border-white/5 pl-2', 
      suppressSizeToFit: true,
      resizable: false,
      sortable: false,
      filter: false,
      lockVisible: true
    },
    { 
      field: "id", 
      headerName: "ID", 
      width: 70,
      minWidth: 70,
      pinned: 'left',
      cellClass: 'text-center font-bold text-slate-500',
      headerClass: 'text-center',
      filter: 'agNumberColumnFilter',
    },
    { 
      field: "name", 
      headerName: "Name", 
      pinned: 'left',
      width: 180,
      minWidth: 180,
      cellClass: 'text-left font-bold uppercase text-blue-400',
      headerClass: 'text-left',
      filter: 'agTextColumnFilter',
      hide: hiddenColumns.includes("name")
    },
    { field: "system", headerName: "System", minWidth: 100, flex: 1, cellClass: 'text-center font-bold text-slate-400 uppercase', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("system") },
    { 
      field: "type", 
      headerName: "Type", 
      width: 100,
      minWidth: 100,
      cellClass: 'text-center',
      headerClass: 'text-center',
      filter: 'agTextColumnFilter',
      cellRenderer: (p: any) => {
        const colors: any = {
          Physical: 'text-emerald-400',
          Virtual: 'text-blue-400',
          Storage: 'text-amber-400',
          Switch: 'text-rose-400',
          Firewall: 'text-orange-400',
          'Load Balancer': 'text-purple-400'
        }
        return <span style={{ fontSize: `${fontSize}px` }} className={`font-bold uppercase ${colors[p.value] || 'text-slate-500'}`}>{p.value || 'N/A'}</span>
      },
      hide: hiddenColumns.includes("type")
    },
    { 
      field: "status", 
      headerName: "Status", 
      width: 110,
      minWidth: 110,
      cellClass: 'text-center',
      headerClass: 'text-center',
      filter: 'agTextColumnFilter',
      cellRenderer: (p: any) => {
        const colors: any = {
          Active: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/20',
          Maintenance: 'text-amber-400 border-amber-500/40 bg-amber-500/20',
          Decommissioned: 'text-rose-400 border-rose-500/40 bg-rose-500/20',
          Planned: 'text-blue-400 border-blue-500/40 bg-blue-500/20',
          Standby: 'text-sky-400 border-sky-500/40 bg-sky-500/20',
          Offline: 'text-slate-400 border-white/20 bg-white/10'
        }
        return (
          <div className="flex items-center justify-center h-full w-full">
            <div className={`flex items-center justify-center w-24 h-5 rounded-lg border shadow-sm ${colors[p.value] || 'text-slate-400 border-white/10 bg-white/5'}`}>
              <span style={{ fontSize: `${fontSize}px` }} className="font-bold uppercase tracking-tighter leading-none">
                {p.value || 'Unknown'}
              </span>
            </div>
          </div>
        )
      },
      hide: hiddenColumns.includes("status")
    },

    { field: "environment", headerName: "Env", width: 80, minWidth: 80, cellClass: 'text-center font-bold text-slate-500 uppercase', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("environment") },
    { field: "owner", headerName: "Owner", width: 90, minWidth: 90, cellClass: 'text-center font-bold text-slate-400', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("owner") },
    { field: "manufacturer", headerName: "Make", width: 80, minWidth: 80, cellClass: 'text-center font-bold text-slate-500', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("manufacturer") },
    { field: "model", headerName: "Model", width: 90, minWidth: 90, cellClass: 'text-center font-bold text-slate-400', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("model") },
    { field: "os_name", headerName: "OS", width: 80, minWidth: 80, cellClass: 'text-center font-bold text-blue-400', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("os_name") },
    { field: "os_version", headerName: "Ver", width: 60, minWidth: 60, cellClass: 'text-center font-bold text-slate-500', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("os_version") },
    { 
      field: "primary_ip", headerName: "Primary IP", width: 110, minWidth: 110, cellClass: 'text-center font-bold text-blue-400', headerClass: 'text-center', filter: 'agTextColumnFilter', 
      cellRenderer: (p: any) => p.value ? (
        <div className="flex items-center justify-center space-x-1">
          <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span>
          <CopyButton value={p.value} label="IP" />
        </div>
      ) : <span className="text-slate-500 uppercase">N/A</span>,
      hide: hiddenColumns.includes("primary_ip")
    },
    { 
      field: "management_ip", headerName: "Mgmt IP", width: 110, minWidth: 110, cellClass: 'text-center font-bold text-indigo-400', headerClass: 'text-center', filter: 'agTextColumnFilter', 
      cellRenderer: (p: any) => p.value ? (
        <div className="flex items-center justify-center space-x-1">
          <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span>
          <CopyButton value={p.value} label="IP" />
        </div>
      ) : <span className="text-slate-500 uppercase">N/A</span>,
      hide: hiddenColumns.includes("management_ip")
    },
    { 
      field: "hardware_summary", 
      headerName: "Resources", 
      minWidth: 120,
      flex: 1,
      cellClass: 'text-center font-bold uppercase text-slate-400',
      headerClass: 'text-center',
      filter: 'agTextColumnFilter',
      cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>,
      hide: hiddenColumns.includes("hardware_summary")
    },
    { 
      field: "hardware_age", 
      headerName: "Age", 
      width: 80,
      minWidth: 80,
      cellClass: 'text-center font-bold text-slate-500',
      headerClass: 'text-center',
      filter: 'agTextColumnFilter',
      cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>,
      hide: hiddenColumns.includes("hardware_age")
    },
    { 
      field: "open_incident_count", 
      headerName: "Health", 
      width: 60,
      minWidth: 60,
      cellClass: 'text-center font-bold',
      headerClass: 'text-center',
      cellRenderer: (p: any) => p.value > 0 ? (
        <div className="flex items-center justify-center h-full w-full">
           <div className="flex items-center space-x-1 bg-rose-500/10 border border-rose-500/30 px-2 py-0.5 rounded-lg text-rose-500">
              <AlertCircle size={10} className="animate-pulse" />
              <span style={{ fontSize: `${fontSize}px` }} className="font-bold">{p.value}</span>
           </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-full text-emerald-500/30"><Check size={12}/></div>
      ),
      hide: hiddenColumns.includes("open_incident_count")
    },

    { field: "site_name", headerName: "Site", width: 100, minWidth: 100, cellClass: 'text-center font-bold text-slate-400', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("site_name") },
    { field: "rack_name", headerName: "Rack", width: 100, minWidth: 100, cellClass: 'text-center font-bold text-slate-400', headerClass: 'text-center', filter: 'agTextColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("rack_name") },
    { 
      field: "depth", 
      headerName: "Depth", 
      width: 80,
      minWidth: 80,
      cellClass: 'text-center',
      headerClass: 'text-center',
      filter: 'agTextColumnFilter',
      cellRenderer: (p: any) => <span style={{ fontSize: `${fontSize}px` }} className="font-bold text-slate-500 uppercase">{p.value || 'N/A'}</span>,
      hide: hiddenColumns.includes("depth")
    },
    { 
      field: "mount_orientation", 
      headerName: "Mount", 
      width: 90,
      minWidth: 90,
      cellClass: 'text-center', 
      headerClass: 'text-center', 
      filter: 'agTextColumnFilter',
      cellRenderer: (p: any) => <span style={{ fontSize: `${fontSize}px` }} className="font-bold text-slate-500 uppercase">{p.value || 'N/A'}</span>,
      hide: hiddenColumns.includes("mount_orientation")
    },
    { field: "u_start", headerName: "U Pos", width: 60, minWidth: 60, cellClass: "text-center font-bold", headerClass: 'text-center', filter: 'agNumberColumnFilter', cellRenderer: (p: any) => p.value ? <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span> : <span style={{ fontSize: `${fontSize}px` }} className="text-slate-500 font-bold uppercase">N/A</span>, hide: hiddenColumns.includes("u_start") },
    { field: "size_u", headerName: "Size", width: 60, minWidth: 60, cellClass: "text-center font-bold", headerClass: 'text-center', filter: 'agNumberColumnFilter', cellRenderer: (p: any) => <span style={{ fontSize: `${fontSize}px` }}>{p.value}</span>, hide: hiddenColumns.includes("size_u") },
    { field: "power_typical_w", headerName: "Avg W", width: 80, minWidth: 80, cellClass: "text-center font-bold", headerClass: 'text-center', cellRenderer: (p: any) => <span style={{ fontSize: `${fontSize}px` }}>{p.value ? `${p.value.toFixed(0)}W` : '–'}</span>, hide: hiddenColumns.includes("power_typical_w") },
    { field: "power_max_w", headerName: "Max W", width: 80, minWidth: 80, cellClass: "text-center font-bold", headerClass: 'text-center', cellRenderer: (p: any) => <span style={{ fontSize: `${fontSize}px` }}>{p.value ? `${p.value.toFixed(0)}W` : '–'}</span>, hide: hiddenColumns.includes("power_max_w") },
    {
      headerName: "Action",
      width: 120,
      minWidth: 120,
      pinned: 'right',
      cellClass: 'text-center',
      headerClass: 'text-center',
      resizable: false,
      cellRenderer: (p: any) => (
        <div className="flex items-center justify-center space-x-1 h-full">
           <div className="flex rounded-lg p-0.5 border border-white/5 bg-transparent">
               <button onClick={() => {
                 const url = getAssetConsoleUrl(p.data)
                 if (!url) return toast.error("No management endpoint configured")
                 window.open(url, '_blank')
               }} title="Quick Console Access" className="p-1.5 text-indigo-400 hover:text-indigo-200 transition-all border-r border-white/5"><Terminal size={14}/></button>
               <button onClick={() => setActiveDetails(p.data)} title="View Details" className="p-1.5 text-blue-400 hover:text-blue-200 transition-all"><Eye size={14}/></button>
               <button onClick={() => setActiveModal(p.data)} title="Edit Configuration" className="p-1.5 text-emerald-400 hover:text-emerald-200 transition-all"><Edit2 size={14}/></button>
               {activeTab !== 'deleted' ? (
                 <button onClick={() => openConfirm('Soft Delete', 'Move this asset to deleted?', () => bulkMutation.mutate({ action: 'delete', ids: [p.data.id] }))} title="Soft Delete" className="p-1.5 text-rose-400 hover:text-rose-200 transition-all"><Trash2 size={14}/></button>
               ) : (
                 <button onClick={() => openConfirm('Purge Registry', 'PURGE PERMANENTLY?', () => bulkMutation.mutate({ action: 'purge', ids: [p.data.id] }))} title="Purge" className="p-1.5 text-rose-400 hover:text-rose-200 transition-all"><Trash2 size={14}/></button>
               )}
           </div>
        </div>
      ),
      lockVisible: true
    }
  ], [activeTab, hiddenColumns, fontSize]) as any

  const handleExportCSV = () => {
    if (gridApi) {
      gridApi.exportDataAsCsv({
        fileName: `SysGrid_Assets_${new Date().toISOString().split('T')[0]}.csv`,
        allColumns: false, // only currently viewed columns
        onlySelected: false // everything in view (filtered, etc)
      })
    }
  }

  const handleCopyToClipboard = () => {
    if (gridApi) {
      const csvData = gridApi.getDataAsCsv({
        allColumns: false,
        onlySelected: true,
        suppressQuotes: true
      })
      if (csvData) {
        navigator.clipboard.writeText(csvData)
          .then(() => toast.success("Table data copied to clipboard"))
          .catch(() => toast.error("Failed to copy data"))
      }
    }
  }

const QuickLookPanel = ({ asset, onClose, onEdit, options, devices }: any) => {
  if (!asset) return null
  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="absolute top-0 right-0 bottom-0 w-[450px] bg-slate-950 border-l border-blue-500/30 shadow-[-20px_0_50px_rgba(0,0,0,0.5)] z-[100] flex flex-col backdrop-blur-2xl"
    >
       <div className="p-8 border-b border-white/5 flex items-center justify-between bg-blue-600/5">
          <div className="flex items-center gap-4">
             <div className="p-3 bg-blue-600/20 text-blue-400 rounded-lg border border-blue-500/20">
                <Search size={24} />
             </div>
             <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">{asset.name}</h3>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{asset.system} // {asset.type}</p>
             </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-lg text-slate-500 hover:text-white transition-all">
             <X size={24} />
          </button>
       </div>

       <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-8">
          <div className="grid grid-cols-2 gap-4">
             <div className="p-4 bg-black/40 border border-white/5 rounded-lg">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Status</p>
                <div className="flex items-center gap-2">
                   <div className={`w-2 h-2 rounded-full ${asset.status === 'Active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                   <span className={`text-xs font-black uppercase ${asset.status === 'Active' ? 'text-emerald-400' : 'text-amber-400'}`}>{asset.status}</span>
                </div>
             </div>
             <div className="p-4 bg-black/40 border border-white/5 rounded-lg">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Environment</p>
                <span className="text-xs font-black uppercase text-blue-400">{asset.environment}</span>
             </div>
          </div>

          <div className="space-y-4">
             <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-white/5 pb-2">Network Vector</h4>
             <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-white/[0.02]">
                   <span className="text-[10px] font-bold text-slate-400 uppercase">Primary IP</span>
                   <span className="text-[11px] font-mono font-bold text-white">{asset.primary_ip || 'N/A'}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-white/[0.02]">
                   <span className="text-[10px] font-bold text-slate-400 uppercase">Mgmt URL</span>
                   <span className="text-[11px] font-mono font-bold text-blue-400 truncate max-w-[200px]">{asset.management_url || 'N/A'}</span>
                </div>
             </div>
          </div>

          <div className="space-y-4">
             <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-white/5 pb-2">Hardware Registry</h4>
             <p className="text-xs font-bold text-slate-300 leading-relaxed uppercase italic">"{asset.hardware_summary || 'No hardware description captured.'}"</p>
          </div>

          <div className="pt-8">
             <button 
               onClick={() => onEdit(asset)}
               className="w-full py-4 bg-blue-600 text-white rounded-lg font-black uppercase text-[11px] tracking-widest shadow-lg shadow-blue-500/20 hover:bg-blue-500 transition-all flex items-center justify-center gap-3"
             >
                <Edit2 size={16} />
                Engage Full Configuration
             </button>
          </div>
       </div>
    </motion.div>
  )
}

  return (
    <div className="h-full flex flex-col space-y-4 relative overflow-hidden">
      <div className="flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-6">
           <div>
              <h1 className="text-3xl font-black uppercase tracking-tighter text-white">Infrastructure <span className="text-blue-500">Registry</span></h1>
              <p className="text-[10px] text-slate-500 uppercase tracking-[0.4em] font-black mt-1 italic">Central Global Asset Inventory</p>
           </div>

           <div className="flex bg-white/5 p-1 rounded-lg border border-white/5 ml-2">
                <button onClick={() => setViewMode('grid')} className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all flex items-center space-x-2 ${viewMode === 'grid' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
                    <LayoutGrid size={14}/> <span>Table</span>
                </button>
                <button onClick={() => setViewMode('report')} className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all flex items-center space-x-2 ${viewMode === 'report' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
                    <FileText size={14}/> <span>List</span>
                </button>
                <button onClick={() => setViewMode('map')} className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all flex items-center space-x-2 ${viewMode === 'map' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
                    <Globe size={14}/> <span>Map</span>
                </button>
           </div>

           {viewMode === 'grid' && (
             <div className="flex bg-white/5 p-1 rounded-lg border border-white/5">
                  <button onClick={() => { setActiveTab('inventory'); setSelectedIds([]) }} className={`px-6 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'inventory' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
                      Existing
                  </button>
                  <button onClick={() => { setActiveTab('deleted'); setSelectedIds([]) }} className={`px-6 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'deleted' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
                      Purged
                  </button>
             </div>
           )}
        </div>

        {viewMode === 'grid' && (
          <div className="flex items-center space-x-3">
            <div className="relative">
               <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
               <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search assets..." className="bg-white/5 border border-white/5 rounded-lg pl-10 pr-4 py-2 text-[10px] font-bold outline-none focus:border-blue-500/50 w-64 transition-all" />
            </div>

            <div className="flex items-center gap-1 rounded-lg border border-white/5 bg-white/5 p-1">
              {[
                { id: 'all', label: 'All' },
                { id: 'mine', label: 'My Systems' },
                { id: 'team', label: 'Team' },
                { id: 'unowned', label: 'Unowned' },
                { id: 'degraded', label: 'Degraded' },
                { id: 'at_risk', label: 'At Risk' },
                { id: 'needs_docs', label: 'Needs Docs' }
              ].map((lens) => (
                <button
                  key={lens.id}
                  onClick={() => setActiveLens(lens.id as any)}
                  className={`rounded-lg px-3 py-2 text-[9px] font-bold uppercase tracking-widest transition-all ${
                    activeLens === lens.id
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                      : 'text-slate-500 hover:bg-white/10 hover:text-slate-200'
                  }`}
                >
                  {lens.label}
                </button>
              ))}
            </div>

            <div className="flex bg-white/5 rounded-lg p-0.5 border border-white/5 space-x-1">
               <button onClick={() => setShowStyleLab(!showStyleLab)} className={`p-1.5 hover:bg-white/10 ${showStyleLab ? 'text-blue-400 bg-white/10' : 'text-slate-500'} rounded-lg transition-all`} title="Toggle Style Lab">
                  <Activity size={16} />
               </button>
               <button onClick={() => setShowColumnPicker(!showColumnPicker)} className={`p-1.5 hover:bg-white/10 ${showColumnPicker ? 'text-blue-400 bg-white/10' : 'text-slate-500'} rounded-lg transition-all`} title="Column Picker">
                  <Sliders size={16} />
               </button>
               <button onClick={handleExportCSV} className="p-1.5 hover:bg-white/10 text-slate-500 hover:text-emerald-400 rounded-lg transition-all" title="Export CSV">
                  <FileText size={16} />
               </button>
               <button onClick={() => setShowImportModal(true)} className="p-1.5 hover:bg-white/10 text-slate-500 hover:text-blue-400 rounded-lg transition-all" title="Import Bulk Data">
                  <Upload size={16} />
               </button>
               <button onClick={handleCopyToClipboard} className="p-1.5 hover:bg-white/10 text-slate-500 hover:text-blue-400 rounded-lg transition-all" title="Copy to Clipboard">
                  <Clipboard size={16} />
               </button>
               <button onClick={() => setShowConfig(true)} className="p-1.5 hover:bg-white/10 text-slate-500 hover:text-blue-400 rounded-lg transition-all" title="Registry Config">
                  <Settings size={16} />
               </button>
            </div>

            <div className="relative bulk-menu-container">
              <button
                onClick={() => setShowBulkMenu(!showBulkMenu)}
                disabled={selectedIds.length === 0 && compareCandidateIds.length < 2}
                className={`p-1.5 rounded-lg border transition-all ${selectedIds.length > 0 || compareCandidateIds.length >= 2 ? 'bg-blue-600/10 border-blue-500/30 text-blue-400' : 'bg-white/5 border-white/5 text-slate-700 cursor-not-allowed'}`}
              >
                <MoreVertical size={18}/>
              </button>
              <AnimatePresence>
                {showBulkMenu && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} className="absolute right-0 mt-2 w-56 bg-slate-900 border border-white/10 rounded-lg shadow-2xl z-50 p-2 space-y-1">
                     <p className="px-3 py-2 text-[8px] font-bold text-slate-500 uppercase tracking-widest border-b border-white/5 mb-1">{selectedIds.length} Assets Selected</p>
                     {activeTab === 'deleted' ? (
                       <button onClick={() => bulkMutation.mutate({ action: 'restore' })} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase hover:bg-white/5 rounded-lg text-emerald-400 transition-all">Restore Selected</button>
                     ) : (
                       <>
                          {selectedIds.length >= 2 && (
                            <button onClick={() => { setCompareSnapshotIds(selectedIds); setViewMode('compare'); setShowBulkMenu(false); }} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase hover:bg-white/5 rounded-lg text-indigo-400 transition-all flex items-center justify-between">
                               <span>Compare Selected</span>
                               <ArrowRightLeft size={12} />
                            </button>
                          )}
                          {selectedIds.length < 2 && compareCandidateIds.length >= 2 && (
                            <button onClick={() => { setSelectedIds(compareCandidateIds); setCompareSnapshotIds(compareCandidateIds); setViewMode('compare'); setShowBulkMenu(false); }} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase hover:bg-white/5 rounded-lg text-sky-400 transition-all flex items-center justify-between">
                               <span>Compare Visible</span>
                               <ArrowRightLeft size={12} />
                            </button>
                          )}
                          <button onClick={() => { setIsBulkStatusOpen(true); setShowBulkMenu(false); }} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase hover:bg-white/5 rounded-lg text-blue-400 transition-all">Set Status...</button>
                          <button onClick={() => { setIsBulkEnvOpen(true); setShowBulkMenu(false); }} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase hover:bg-white/5 rounded-lg text-slate-400 transition-all">Set Environment...</button>
                       </>
                     )}
                     <div className="h-px bg-white/5 mx-2 my-1" />
                     <button onClick={() => { 
                         const title = activeTab === 'deleted' ? 'Purge Assets' : 'Soft Delete'
                         const msg = activeTab === 'deleted' ? 'PURGE PERMANENTLY?' : 'Soft-delete assets?'
                         openConfirm(title, msg, () => bulkMutation.mutate({ action: activeTab === 'deleted' ? 'purge' : 'delete' }))
                      }} className="w-full text-left px-4 py-2 text-[10px] font-bold uppercase hover:bg-rose-500/20 rounded-lg text-rose-500 transition-all">{activeTab === 'deleted' ? 'Bulk Purge' : 'Bulk Delete'}</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button onClick={() => setActiveModal({})} className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all">+ Add Asset</button>
          </div>
        )}
      </div>

        {viewMode === 'grid' && <AssetInsightBar assets={devices || []} />}

      {/* STYLE LABORATORY BAR REMOVED AND MOVED TO SIDEBAR */}
      {viewMode === 'grid' ? (
        <div className="flex-1 w-full glass-panel rounded-lg overflow-hidden ag-theme-alpine-dark relative shadow-2xl border border-white/5">
          {isLoading && (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#020617]/80 backdrop-blur-sm space-y-4 text-blue-400">
               <RefreshCcw size={32} className="animate-spin" />
               <p className="text-[10px] font-bold uppercase tracking-[0.3em]">Syncing asset registry...</p>
            </div>
          )}
          <AgGridReact
            ref={gridRef}
            rowData={visibleAssets || []}
            columnDefs={columnDefs}
            rowSelection="multiple"
            headerHeight={fontSize + rowDensity + 10}
            rowHeight={fontSize + rowDensity + 10}
            onGridReady={(params) => {
              setGridApi(params.api)
              setGridColumnApi(params.columnApi)
              if (statusParam) {
                params.api.setFilterModel({ status: { filterType: 'text', type: 'equals', filter: statusParam } })
              }
            }}
            onSelectionChanged={(e) => {
              const nodes = e?.api?.getSelectedNodes() || []
              setSelectedIds(nodes.map((n: any) => n.data?.id).filter(Boolean))
              if (nodes.length === 1) setQuickLookId(nodes[0].data?.id)
              else setQuickLookId(null)
            }}
            enableCellTextSelection={true}
          />

          <AnimatePresence>
            {quickLookId && (
              <QuickLookPanel 
                asset={devices?.find((d:any) => d.id === quickLookId)} 
                onClose={() => { setQuickLookId(null); gridRef.current?.api?.deselectAll(); }} 
                onEdit={(a: any) => { setQuickLookId(null); setActiveModal(a); }}
              />
            )}
          </AnimatePresence>
          <AnimatePresence>
            {showColumnPicker && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="absolute top-0 right-0 bottom-0 w-64 bg-slate-950/90 backdrop-blur-xl border-l border-white/10 z-[60] flex flex-col shadow-2xl"
              >
                <div className="p-6 border-b border-white/5 flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-blue-400 flex items-center space-x-2">
                    <Sliders size={14} /> <span>Toggle Columns</span>
                  </h3>
                  <button onClick={() => setShowColumnPicker(false)} className="text-slate-500 hover:text-white"><X size={18}/></button>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-1">
                  {columnDefs.filter((c: any) => c.field && !c.lockVisible).map((col: any) => (
                    <label key={col.field} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-white/5 cursor-pointer group transition-all">
                      <div className="relative flex items-center">
                        <input
                          type="checkbox"
                          checked={!hiddenColumns.includes(col.field)}
                          onChange={() => {
                            if (hiddenColumns.includes(col.field)) {
                              setHiddenColumns(hiddenColumns.filter(f => f !== col.field))
                            } else {
                              setHiddenColumns([...hiddenColumns, col.field])
                            }
                          }}
                          className="sr-only"
                        />
                        <div className={`w-4 h-4 rounded-lg border transition-all ${!hiddenColumns.includes(col.field) ? 'bg-blue-600 border-blue-500 shadow-lg shadow-blue-500/20' : 'border-white/10 bg-black/40 group-hover:border-white/20'}`}>
                           {!hiddenColumns.includes(col.field) && <Check size={12} className="text-white mx-auto" />}
                        </div>
                      </div>
                      <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${!hiddenColumns.includes(col.field) ? 'text-slate-200' : 'text-slate-500'}`}>{col.headerName || col.field}</span>
                    </label>
                  ))}
                </div>
                <div className="p-4 border-t border-white/5">
                   <button onClick={() => setHiddenColumns([])} className="w-full py-2 text-[9px] font-bold uppercase text-slate-500 hover:text-white transition-colors">Show All Columns</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : viewMode === 'report' ? (
        <AssetReportView
           assets={visibleAssets}
           selectedId={selectedAssetId}
           onSelect={setSelectedAssetId}
           options={options}
           onEdit={(a: any) => setActiveModal(a)}
           onViewServiceDetails={(s: any) => setActiveServiceDetails(s)}
           onEditService={(s: any) => setActiveServiceEdit(s)}
           devices={devices}
           onViewAssetDetails={setActiveDetails}
        />
      ) : viewMode === 'compare' ? (
        <AssetComparisonView
          assets={compareAssets}
          selectedIds={compareSnapshotIds}
          onBack={() => { setViewMode('grid'); setCompareSnapshotIds([]) }}
          onSync={(key, value, ids) => bulkMutation.mutate({ action: 'update', payload: { [key]: value }, ids })}
        />

      ) : (
        <div className="flex-1 glass-panel rounded-lg overflow-hidden relative border-white/5 bg-slate-950">
           <AssetMap 
             assets={visibleAssets} 
             connections={allConnections || []}
             relationships={allRelationships || []}
             systemsList={options?.filter((o:any)=>o.category==='LogicalSystem').map((o:any)=>o.value) || []}
           />
        </div>
      )}
      <StatusBulkUpdateModal
        isOpen={isBulkStatusOpen}
        onClose={() => setIsBulkStatusOpen(false)}
        onApply={(s) => bulkMutation.mutate({ action: 'update', payload: { status: s } })}
        options={options || []}
        count={selectedIds.length}
      />

      <BulkEnvUpdateModal
        isOpen={isBulkEnvOpen}
        onClose={() => setIsBulkEnvOpen(false)}
        onApply={(e) => bulkMutation.mutate({ action: 'update', payload: { environment: e } })}
        options={options || []}
        count={selectedIds.length}
      />

      <ConfirmationModal 
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
      />

      <WorkspaceModal
        isOpen={!!activeModal}
        onClose={() => setActiveModal(null)}
        size="workspace"
        isMaximized={isMaximized}
        onMaximizeToggle={() => setIsMaximized(!isMaximized)}
        title={activeModal?.id ? 'Modify Asset Configuration' : 'New Asset Registration'}
        subtitle="Asset Identity, Classification & Life-cycle"
        icon={<Package size={20}/>}
        footerRight={
          <ToolbarButton onClick={() => setActiveModal(null)}>Close</ToolbarButton>
        }
      >
        <AssetForm initialData={activeModal} onSave={mutation.mutate} options={options} isSaving={mutation.isPending} devices={devices} />
      </WorkspaceModal>

      <WorkspaceModal
        isOpen={!!activeDetails}
        onClose={() => setActiveDetails(null)}
        size="workspace"
        isMaximized={isMaximized}
        onMaximizeToggle={() => setIsMaximized(!isMaximized)}
        title={
          <div className="flex items-center gap-3">
             {activeDetails?.name || 'Asset Details'}
             <WorkspaceShareHeader id={String(activeDetails?.id)} title={activeDetails?.name || 'Asset'} />
          </div>
        }
        subtitle={`${activeDetails?.system} · ${activeDetails?.type} · ${activeDetails?.primary_ip || 'No IP'}`}
        icon={<Eye size={20}/>}
        footerRight={
          <ToolbarButton onClick={() => setActiveDetails(null)}>Close</ToolbarButton>
        }
      >
        <div className="pt-6">
          {activeDetails && (
            <AssetDetailsView
              device={activeDetails}
              options={options}
              onViewServiceDetails={(s:any) => setActiveServiceDetails(s)}
              onEditService={(s:any) => setActiveServiceEdit(s)}
              onEditLink={(l:any) => setActiveNetworkEdit(l)}
              onViewLink={(l:any) => setSelectedConnection(l)}
            />
          )}
        </div>
      </WorkspaceModal>

      <BulkImportModal 
        isOpen={showImportModal} 
        onClose={() => setShowImportModal(false)} 
        tableName="devices" 
        displayName="Infrastructure Assets" 
      />

      <SharedServiceModals 
        activeDetails={activeServiceDetails}
        setActiveDetails={setActiveServiceDetails}
        activeEdit={activeServiceEdit}
        setActiveEdit={setActiveServiceEdit}
        options={options}
        devices={devices}
        onServiceUpdate={() => {
          queryClient.invalidateQueries({ queryKey: ['device-services'] })
        }}
      />

               <SharedNetworkModals 
                 activeEdit={activeNetworkEdit}
                 setActiveEdit={setActiveNetworkEdit}
                 options={options}
                 devices={devices}
                 onUpdate={() => {
                   queryClient.invalidateQueries({ queryKey: ['device-interfaces'] })
                   queryClient.invalidateQueries({ queryKey: ['connections'] })
                 }}
               />

               {selectedConnection && createPortal(
                 <ConnectionForensicsModal
                   isOpen={!!selectedConnection}
                   onClose={() => setSelectedConnection(null)}
                   connection={selectedConnection}
                 />,
                 document.body
               )}
      <ConfigRegistryModal
        isOpen={showConfig}
        onClose={() => setShowConfig(false)}
        title="Asset Registry Enumerations"
        sections={[
            { title: "Asset Types", category: "DeviceType", icon: Box },
            { title: "Hardware Profiles", category: "HardwareProfile", icon: Package },
            { title: "Logical Systems", category: "LogicalSystem", icon: LayoutGrid },
            { title: "Business Units", category: "BusinessUnit", icon: Sliders }
        ]}
      />

      <style>{`
        .ag-theme-alpine-dark {
          --ag-background-color: #1a1b26;
          --ag-header-background-color: #24283b;
          --ag-border-color: rgba(255,255,255,0.05);
          --ag-foreground-color: #f1f5f9;
          --ag-header-foreground-color: #3b82f6;
          --ag-font-family: 'Inter', sans-serif;
          --ag-font-size: ${fontSize}px;
        }
        .ag-root-wrapper { border: none !important; }
        .ag-header-cell-label { 
            font-weight: 700 !important; 
            text-transform: uppercase !important; 
            letter-spacing: 0.1em !important; 
            font-size: ${fontSize}px !important; 
            justify-content: center !important; 
        }
        .ag-cell { 
            display: flex; 
            align-items: center; 
            justify-content: center !important; 
            font-weight: 700 !important;
            font-size: ${fontSize}px !important;
        }
        
        .ag-row-hover { background-color: rgba(255,255,255,0.05) !important; }
        .ag-row-selected { background-color: rgba(59, 130, 246, 0.2) !important; }

        /* Make filter popups non-transparent and on top */
        .ag-popup { z-index: 1000 !important; }
        .ag-filter-wrapper { background-color: #141721 !important; border: 1px solid rgba(255,255,255,0.1) !important; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.4) !important; border-radius: 12px !important; opacity: 1 !important; }
        .ag-filter-body { background-color: #141721 !important; padding: 12px !important; }
      `}</style>
    </div>
  )
}

const MetadataTab = ({ device, onSave }: { device: any, onSave: (d: any) => void }) => {
    const [mode, setMode] = useState<'view' | 'edit'>('view')
    const [metadataError, setMetadataError] = useState<string | null>(null)
    const [localData, setLocalData] = useState({ ...device })

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
                <div className="flex space-x-1 bg-black/40 p-1 rounded-lg w-fit">
                    <button onClick={() => setMode('view')} className={`px-4 py-1.5 rounded-lg text-[9px] font-bold uppercase tracking-widest transition-all ${mode === 'view' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}>Read-Only View</button>
                    <button onClick={() => setMode('edit')} className={`px-4 py-1.5 rounded-lg text-[9px] font-bold uppercase tracking-widest transition-all ${mode === 'edit' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}>Edit Metadata</button>
                </div>
                {mode === 'edit' && (
                    <button 
                        disabled={!!metadataError}
                        onClick={() => onSave(localData)} 
                        className="px-6 py-2 bg-emerald-600 text-white rounded-lg text-[10px] font-bold uppercase shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                    >
                        Save Metadata
                    </button>
                )}
            </div>
            
            <div className="bg-black/20 rounded-lg p-2">
                {mode === 'view' ? (
                    <MetadataViewer data={localData.metadata_json} />
                ) : (
                    <MetadataEditor 
                        value={localData.metadata_json} 
                        onChange={v => setLocalData({...localData, metadata_json: v})} 
                        onError={setMetadataError}
                    />
                )}
            </div>
        </div>
    )
}

const NetworkingTab = ({ deviceId, onEditLink, onViewLink }: { deviceId: number, onEditLink: (l: any) => void, onViewLink: (l: any) => void }) => {
  const queryClient = useQueryClient()
  const { data: device, isLoading: isDeviceLoading } = useQuery({
    queryKey: ['device', deviceId],
    queryFn: async () => (await (await apiFetch(`/api/v1/devices/${deviceId}`)).json()),
    staleTime: 300000,
    initialData: () => {
      const allDevices = queryClient.getQueryData<any[]>(['devices'])
      return allDevices?.find(d => d.id === deviceId)
    }
  })

  // Source network info only for this device to optimize performance
  const { data: connections, isLoading: isConnsLoading } = useQuery({ 
    queryKey: ['connections', deviceId], 
    queryFn: async () => (await (await apiFetch(`/api/v1/networks/connections?device_id=${deviceId}`)).json()),
    staleTime: 60000
  })

  // Fetch Hardware Templates
  const { data: templates } = useQuery({
    queryKey: ['options', 'HardwareProfile'],
    queryFn: async () => (await (await apiFetch('/api/v1/settings/options?category=HardwareProfile')).json())
  })

  const saveTemplateMutation = useMutation({
    mutationFn: async () => {
      const activePorts = Array.from(new Set(connections?.map((c: any) => c.source_device_id === deviceId ? c.source_port : c.target_port)))
      const portStrings = activePorts.map(p => `${p}:RJ45`) // Default to RJ45 for ad-hoc
      const res = await apiFetch('/api/v1/settings/options', {
        method: 'POST',
        body: JSON.stringify({
          category: 'HardwareProfile',
          label: device?.model || 'New Template',
          value: device?.model || 'New Template',
          metadata_keys: portStrings
        })
      })
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['options', 'HardwareProfile'] })
      alert('Model template saved successfully to Settings.')
    }
  })

  if (isConnsLoading || isDeviceLoading) return <div className="py-20 text-center"><RefreshCcw className="animate-spin mx-auto text-blue-500 mb-4" /> <span className="text-[10px] font-bold uppercase text-slate-500 tracking-widest">Hydrating Fabric Data...</span></div>

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      <div className="flex items-center justify-between px-2">
         <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-indigo-600 pl-3">Physical Port Visualization</h3>
         <button 
           onClick={() => saveTemplateMutation.mutate()}
           className="px-3 py-1.5 bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 rounded-lg text-[9px] font-bold uppercase hover:bg-indigo-600/20 transition-all flex items-center gap-2"
         >
           <Save size={12} /> Save {device?.model || 'Model'} Template
         </button>
      </div>

      <DevicePortGrid device={device} connections={connections} templates={templates} />

      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
           <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-emerald-600 pl-3">Network Link Details (Sourced from Fabric)</h3>
        </div>
        <table className="w-full text-[10px]">
          <thead className="bg-white/5 border-b border-white/5">
            <tr>
              <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Local Port</th>
              <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Farm / Status</th>
              <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">IP Address</th>
              <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">MAC / VLAN</th>
              <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Speed</th>
              <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Peer R/S</th>
              <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Connection</th>
              <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {connections?.map((c: any) => {
              const isSource = c.source_device_id === deviceId
              const localPort = isSource ? c.source_port : c.target_port
              const localIP = isSource ? c.source_ip : c.target_ip
              const localMAC = isSource ? c.source_mac : c.target_mac
              const localVLAN = isSource ? c.source_vlan : c.target_vlan
              const peerName = isSource ? c.server_b : c.server_a
              const peerPort = isSource ? c.target_port : c.source_port
              const peerRS = isSource ? `${c.peer_rack || '?'}:${c.peer_slot || '?'}` : `${c.src_rack || '?'}:${c.src_slot || '?'}`
              
              const statusColors: any = {
                Active: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
                Requested: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
                Maintenance: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
                Planned: 'text-blue-400 bg-blue-500/10 border-blue-500/20'
              }

              return (
                <tr key={c.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-4 py-3 font-bold text-blue-400 uppercase tracking-tight text-[10px]">{localPort}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <span className="text-indigo-400 font-black uppercase tracking-tighter">{c.farm || 'N/A'}</span>
                      <span className={`w-fit px-1.5 py-0.5 rounded-lg text-[8px] font-black uppercase border ${statusColors[c.status] || 'text-slate-400 bg-white/5 border-white/10'}`}>
                        {c.status || 'Active'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-bold text-slate-200 text-[10px]">{localIP || <span className="text-slate-700 ">Unassigned</span>}</td>
                  <td className="px-4 py-3">
                     <div className="flex flex-col">
                        <span className="text-slate-500 text-[10px] uppercase font-bold">{localMAC || 'N/A'}</span>
                        {localVLAN && <span className="text-[10px] font-bold text-indigo-400 uppercase mt-0.5">VLAN {localVLAN}</span>}
                     </div>
                  </td>
                  <td className="px-4 py-3 text-center">
                     <span className="text-slate-400 font-bold text-[10px]">{c.speed}</span>
                  </td>
                  <td className="px-4 py-3 text-center font-bold text-slate-500 uppercase">
                    {peerRS}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button 
                      onClick={() => onViewLink(c)}
                      className="px-2 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg text-[10px] font-bold uppercase hover:bg-emerald-500/20 transition-all flex items-center gap-1.5 mx-auto"
                    >
                      <Network size={10} /> {peerName} ({peerPort})
                    </button>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <button onClick={() => onEditLink(c)} className="p-1.5 bg-blue-600/10 text-blue-400 border border-blue-500/20 rounded-lg hover:bg-blue-600/20 transition-all">
                        <Edit2 size={12}/>
                      </button>
                    </div>
                  </td>
                </tr>
              )
            })}
            {!connections?.length && <tr><td colSpan={8}><WorkspaceEmptyState compact title="No active network links found in fabric" /></td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}

const DevicePortGrid = ({ device, connections, templates }: { device: any, connections: any[], templates?: any[] }) => {
  const isSwitch = device?.type === 'Switch'
  const isFirewall = device?.type === 'Firewall' || device?.type === 'Load Balancer'
  const [isExpanded, setIsExpanded] = useState(false)

  const ports = useMemo(() => {
    let basePorts = []

    // 1. Check for exact model template match
    const modelTemplate = templates?.find(t => t.value === device?.model || t.label === device?.model)
    const metadataOverride = device?.metadata_json?.port_definitions
    
    if (modelTemplate?.metadata_keys?.length || metadataOverride) {
      const keysToUse = metadataOverride || modelTemplate.metadata_keys
      basePorts = keysToUse.map((k: string) => {
        const [name, type, category] = k.split(':')
        return { name, type: type || 'RJ45', category: category || 'General' }
      })
    } else {
      // 2. Fall back to standard type layouts if no template exists
      if (isSwitch) {
        for (let i = 1; i <= 48; i++) {
          const name = i <= 24 ? `Gi1/0/${i}` : (i <= 44 ? `Gi1/0/${i}` : `Te1/1/${i-44}`)
          basePorts.push({ name, type: i > 44 ? 'SFP+' : 'RJ45' })
        }
      } else if (isFirewall) {
        for (let i = 0; i < 8; i++) {
          basePorts.push({ name: `eth${i}`, type: 'RJ45' })
        }
        basePorts.push({ name: 'mgmt0', type: 'RJ45', category: 'Management' })
      } else {
        basePorts.push({ name: 'eth0', type: 'RJ45' })
        basePorts.push({ name: 'eth1', type: 'RJ45' })
        basePorts.push({ name: 'mgmt0', type: 'RJ45', category: 'Management' })
      }
    }

    // 3. Perform "Outer Join": Identify active ports from connections that aren't in basePorts
    const activePortNames = new Set(connections?.map(c =>
      c.source_device_id === device?.id ? c.source_port : c.target_port
    ).filter(Boolean))

    const extraPorts = Array.from(activePortNames)
      .filter(name => !basePorts.find(p => p.name === name))
      .map(name => ({ name, type: 'Virtual', category: 'Logical' }))

    return [...basePorts, ...extraPorts]
  }, [isSwitch, isFirewall, connections, device?.id, device?.model, templates, device?.metadata_json?.port_definitions])

  // Create a quick lookup map for connections by port name
  const connMap = useMemo(() => {
    const map: Record<string, any> = {}
    connections?.forEach(c => {
      if (c.source_device_id === device?.id) map[c.source_port] = c
      if (c.target_device_id === device?.id) map[c.target_port] = c
    })
    return map
  }, [connections, device?.id])

  return (
    <div className="bg-black/40 border border-white/5 rounded-lg overflow-hidden transition-all duration-500">
      <button 
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-6 hover:bg-white/5 transition-colors group"
      >
        <div className="flex items-center gap-4">
           <div className={`p-2.5 rounded-lg ${isSwitch ? 'bg-rose-500/20 text-rose-400 border-rose-500/20' : 'bg-blue-500/20 text-blue-400 border-blue-500/20'} border`}>
              <Network size={18} />
           </div>
           <div className="text-left">
              <h4 className="text-md font-black uppercase tracking-tighter text-white flex items-center gap-2">
                Physical Port Topography
                <span className="text-slate-500 opacity-50 font-normal text-[10px]">[{device?.model}]</span>
              </h4>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{isSwitch ? 'High-Density Switching Matrix' : 'Network Interface Stack'}</p>
           </div>
        </div>
        <div className="flex items-center gap-4">
           <div className="flex items-center gap-6 mr-6">
              <div className="flex items-center gap-2">
                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                 <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Active</span>
              </div>
              <div className="flex items-center gap-2">
                 <div className="w-1.5 h-1.5 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />
                 <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Drift</span>
              </div>
           </div>
           {isExpanded ? <ChevronDown className="text-slate-500 group-hover:text-white transition-colors" size={20} /> : <ChevronRight className="text-slate-500 group-hover:text-white transition-colors" size={20} />}
        </div>
      </button>

      <motion.div 
        initial={false}
        animate={{ height: isExpanded ? 'auto' : 0, opacity: isExpanded ? 1 : 0 }}
        className="overflow-hidden bg-slate-900/40"
      >
        <div className="p-8 pt-2 border-t border-white/5">
          <div className={`grid ${isSwitch ? 'grid-cols-12' : 'grid-cols-4'} gap-3`}>
            {ports.map((p: any, idx) => {
              const conn = connMap[p.name]
              const isActive = !!conn
              const isLogical = p.type === 'Virtual'

              // --- DRIFT ANALYSIS (Calculated Inline to avoid Hook violations) ---
              let isDrift = null
              if (isActive && !isLogical) {
                // 1. Speed Drift
                if (p.type === 'SFP+' && conn.speed && !conn.speed.includes('10G') && !conn.speed.includes('25G') && !conn.speed.includes('40G') && !conn.speed.includes('100G')) {
                  isDrift = { type: 'Speed', message: `Performance Degradation: ${p.type} port running at ${conn.speed}` }
                }
                // 2. Medium Drift
                if (p.type === 'RJ45' && conn.speed && (conn.speed.includes('10G') || conn.speed.includes('FIBER'))) {
                   isDrift = { type: 'Medium', message: `Configuration Alert: ${p.type} port with High-Speed ${conn.speed} link` }
                }
              }

              return (
                <div 
                  key={idx} 
                  className={`relative group p-4 rounded-lg border transition-all duration-300 flex flex-col items-center justify-center space-y-2 cursor-help
                    ${isActive 
                      ? (isLogical ? 'bg-blue-500/10 border-blue-500/30 shadow-[0_0_20px_rgba(59,130,246,0.05)]' : 'bg-emerald-500/10 border-emerald-500/30 shadow-[0_0_20px_rgba(16,185,129,0.05)]')
                      : 'bg-black/40 border-white/5 hover:border-white/10'}
                    ${isDrift ? 'ring-2 ring-amber-500/50 ring-offset-2 ring-offset-slate-950 border-amber-500/40' : ''}`}
                >

                  <div className={`w-full h-1 absolute top-0 left-0 rounded-lg transition-all 
                    ${isDrift ? 'bg-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.6)]' : (isActive ? (isLogical ? 'bg-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.5)]' : 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]') : 'bg-transparent')}`} 
                  />
                  
                  <div className={`text-[8px] font-black uppercase tracking-tighter transition-colors ${isDrift ? 'text-amber-400' : (isActive ? (isLogical ? 'text-blue-400' : 'text-emerald-400') : 'text-slate-600')}`}>
                    {p.name}
                  </div>
                  
                  <div className={`w-8 h-6 rounded-lg border flex items-center justify-center transition-all
                    ${isDrift ? 'border-amber-500/50 bg-amber-500/10 text-amber-400' : (isActive ? (isLogical ? 'border-blue-500/50 bg-blue-500/10 text-blue-400' : 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400') : 'border-white/10 bg-slate-900 text-slate-700')}`}
                  >
                    {p.type === 'SFP+' ? <Zap size={12} /> : (p.type === 'Virtual' ? <Globe size={12} /> : <div className="grid grid-cols-2 gap-0.5">
                      <div className="w-1 h-1 rounded-full bg-current opacity-20" />
                      <div className="w-1 h-1 rounded-full bg-current opacity-20" />
                      <div className="w-1 h-1 rounded-full bg-current opacity-20" />
                      <div className="w-1 h-1 rounded-full bg-current opacity-20" />
                    </div>)}
                  </div>

                  {(isActive || isDrift) && (
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-48 bg-slate-900 border border-white/10 p-3 rounded-lg shadow-2xl backdrop-blur-xl">
                        {isDrift && (
                          <div className="mb-2 p-2 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                             <div className="flex items-center gap-1 text-[8px] font-black text-amber-400 uppercase tracking-widest mb-1">
                                <AlertTriangle size={10} /> Forensic Drift Detected
                             </div>
                             <div className="text-[7px] text-amber-200/70 font-medium leading-tight">{isDrift.message}</div>
                          </div>
                        )}
                        <div className="text-[7px] font-black text-slate-500 uppercase tracking-widest mb-1">Target Entity</div>
                        <div className="text-[10px] font-black text-white uppercase truncate mb-2">{conn.server_b === device?.name ? conn.server_a : conn.server_b}</div>
                        <div className="flex items-center justify-between text-[8px] font-black">
                           <span className="text-slate-500 uppercase">Port:</span>
                           <span className="text-indigo-400 uppercase">{conn.source_device_id === device?.id ? conn.target_port : conn.source_port}</span>
                        </div>
                        <div className="flex items-center justify-between text-[8px] font-black mt-1">
                           <span className="text-slate-500 uppercase">Metric:</span>
                           <span className="text-emerald-400 uppercase">{conn.speed}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </motion.div>
    </div>
  )
}

const SecurityTab = ({ device }: { device: any }) => {
  if (!device) return null
  const deviceId = device.id
  const queryClient = useQueryClient()
  const [newRule, setNewRule] = useState({
    name: '',
    risk: '',
    source_type: 'Custom IP',
    source_device_id: null as any,
    source_custom_ip: '',
    dest_type: 'Device',
    dest_device_id: deviceId,
    dest_custom_ip: device.primary_ip || '',
    protocol: 'TCP',
    port_range: '',
    direction: 'Inbound',
    action: 'Allow'
  })

  const [confirmModal, setConfirmModal] = useState<any>({ isOpen: false, id: null })

  const { data: rules, isLoading } = useQuery({ 
    queryKey: ['device-firewall', deviceId], 
    queryFn: async () => (await (await apiFetch(`/api/v1/security/firewall?device_id=${deviceId}`)).json()) 
  })

  const { data: interfaces } = useQuery({ 
    queryKey: ['device-interfaces', deviceId], 
    queryFn: async () => (await (await apiFetch(`/api/v1/devices/${deviceId}/interfaces`)).json()) 
  })

  const { data: devices } = useQuery({
    queryKey: ['devices-list-simple'],
    queryFn: async () => (await (await apiFetch('/api/v1/devices')).json())
  })

  const { data: fabricConnections } = useQuery({ 
    queryKey: ['connections'], 
    queryFn: async () => (await (await apiFetch('/api/v1/networks/connections')).json()) 
  })

  const availableIPs = useMemo(() => {
    const ips: any[] = []
    
    // Add explicitly configured IPs from Device record
    if (device?.primary_ip) ips.push({ value: device.primary_ip, label: `Primary: ${device.primary_ip}` })
    if (device?.management_ip) ips.push({ value: device.management_ip, label: `Mgmt: ${device.management_ip}` })
    
    // Add all IPs discovered in the fabric (connections) for this asset
    const relatedConns = fabricConnections?.filter((c: any) => c.source_device_id === deviceId || c.target_device_id === deviceId) || []
    relatedConns.forEach((c: any) => {
      const isSrc = c.source_device_id === deviceId
      const ip = isSrc ? c.source_ip : c.target_ip
      const port = isSrc ? (c.source_port || c.port_a) : (c.target_port || c.port_b)
      if (ip) {
        ips.push({ value: ip, label: `${ip} [${port}]` })
      }
    })
    
    // Deduplicate IPs based on value to prevent redundant select options, 
    // but prefer the detailed port label over the generic primary/mgmt label if both exist.
    const uniqueIPsMap = new Map()
    ips.forEach(item => {
      const existing = uniqueIPsMap.get(item.value)
      // If we don't have this IP yet, or if the current item has a port label (contains '[')
      // and the existing one was a generic "Primary:" or "Mgmt:" label, replace it.
      if (!existing || (!existing.label.includes('[') && item.label.includes('['))) {
        uniqueIPsMap.set(item.value, item)
      }
    })
    
    return Array.from(uniqueIPsMap.values())
  }, [device, fabricConnections, deviceId])


  const mutation = useMutation({    mutationFn: async (data: any) => {
      const res = await apiFetch('/api/v1/security/firewall', {
        method: 'POST',
        body: JSON.stringify(data)
      })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['device-firewall', deviceId] })
      setNewRule({ 
        name: '', risk: '', source_type: 'Custom IP', source_device_id: null as any, source_custom_ip: '', 
        dest_type: 'Device', dest_device_id: deviceId, dest_custom_ip: '', protocol: 'TCP', port_range: '', 
        direction: 'Inbound', action: 'Allow' 
      })
      toast.success('Firewall Exception Recorded')
    },
    onError: (e: any) => toast.error(e.message)
  })

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiFetch(`/api/v1/security/firewall/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['device-firewall', deviceId] })
      setConfirmModal({ isOpen: false, id: null })
      toast.success('Security Policy Revoked')
    },
    onError: (e: any) => toast.error(e.message)
  })

  return (
    <div className="space-y-6">
      <div className="bg-white/5 p-6 rounded-lg border border-white/5 space-y-4">
        <h3 className="text-[10px] font-bold uppercase text-blue-400 tracking-[0.2em] mb-4">Request Firewall Exception</h3>
        <div className="grid grid-cols-4 gap-4">
          <div className="col-span-2">
            <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1 px-1">Rule Name</label>
            <input value={newRule.name} onChange={e => setNewRule({...newRule, name: e.target.value})} placeholder="e.g. DB Access for Client X" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
          </div>
          <div className="col-span-2">
            <label className="text-[9px] font-bold text-rose-400 uppercase block mb-1 px-1">Risk / Impact if Missing</label>
            <input value={newRule.risk} onChange={e => setNewRule({...newRule, risk: e.target.value})} placeholder="e.g. Critical service outage for production grid" className="w-full bg-slate-900 border border-rose-500/20 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-rose-500" />
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-4 items-end">
          <div>
            <StyledSelect
              label="Protocol"
              value={newRule.protocol}
              onChange={e => setNewRule({...newRule, protocol: e.target.value})}
              options={[{value: 'TCP', label: 'TCP'}, {value: 'UDP', label: 'UDP'}, {value: 'ICMP', label: 'ICMP'}, {value: 'Any', label: 'Any'}]}
            />
          </div>
          <div>
            <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1 px-1">Port(s)</label>
            <input value={newRule.port_range} onChange={e => setNewRule({...newRule, port_range: e.target.value})} placeholder="e.g. 443, 1433" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
          </div>
          <div>
            <StyledSelect
              label="Destination IP *"
              value={newRule.dest_custom_ip || ''}
              onChange={e => setNewRule({...newRule, dest_custom_ip: e.target.value})}
              options={availableIPs}
              placeholder="Select Target IP..."
            />
          </div>
          <div className="col-span-1">
            <StyledSelect
              label="Source Type"
              value={newRule.source_type}
              onChange={e => setNewRule({...newRule, source_type: e.target.value})}
              options={[{value: 'Device', label: 'Device'}, {value: 'Custom IP', label: 'Custom IP/CIDR'}, {value: 'Description', label: 'Description'}]}
            />
          </div>
          <div className="col-span-1">
             {newRule.source_type === 'Device' ? (
                <StyledSelect
                  label="Source Device"
                  value={newRule.source_device_id || ''}
                  onChange={e => setNewRule({...newRule, source_device_id: parseInt(e.target.value)})}
                  options={devices?.map((d:any) => ({ value: String(d.id), label: d.name })) || []}
                />
             ) : (
                <>
                  <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1 px-1">{newRule.source_type === 'Description' ? 'Source Description' : 'Source IP / CIDR'}</label>
                  <input value={newRule.source_custom_ip} onChange={e => setNewRule({...newRule, source_custom_ip: e.target.value})} placeholder={newRule.source_type === 'Description' ? 'e.g. External Cloud' : 'e.g. 10.0.0.1 or 0.0.0.0/0'} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
                </>
             )}
          </div>
        </div>
        
        <div className="flex justify-end pt-2">
          <button 
            onClick={() => { if(!newRule.name || !newRule.port_range) return toast.error("Name and Ports required"); mutation.mutate(newRule) }} 
            className="px-8 py-2.5 bg-blue-600 text-white rounded-lg text-[9px] font-bold uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
          >
            Authorize Exception
          </button>
        </div>
      </div>

      <div className="p-0 overflow-hidden border border-white/5 rounded-lg">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-12 text-slate-500">
            <RefreshCcw size={20} className="animate-spin mb-2" />
            <p className="text-[10px] font-bold uppercase">Retrieving Security Policies...</p>
          </div>
        ) : (
          <table className="w-full text-[10px]">
            <thead className="bg-white/5 border-b border-white/5">
              <tr>
                <th className="px-4 py-3 text-left font-bold uppercase tracking-widest text-slate-500">Rule Name</th>
                <th className="px-4 py-3 text-left font-bold uppercase tracking-widest text-slate-500">Source</th>
                <th className="px-4 py-3 text-left font-bold uppercase tracking-widest text-slate-500">Destination</th>
                <th className="px-4 py-3 text-center font-bold uppercase tracking-widest text-slate-500">Protocol/Ports</th>
                <th className="px-4 py-3 text-center font-bold uppercase tracking-widest text-slate-500">Ops</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {rules?.map((r: any) => (
                <tr key={r.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-4 py-3">
                    <div className="flex flex-col">
                      <span className="font-bold text-white uppercase text-[10px]">{r.name}</span>
                      <span className="text-[10px] text-rose-400 font-bold uppercase tracking-tight">{r.risk || 'Risk not assessed'}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-400 font-bold text-[10px]">
                    {r.source_type === 'Device' ? (
                      <span className="text-blue-400 font-bold">{r.source_device_name}</span>
                    ) : (r.source_custom_ip || 'ANY')}
                  </td>
                  <td className="px-4 py-3 text-slate-400 font-bold text-[10px]">
                    <div className="flex flex-col">
                      <span className="text-emerald-400 font-bold uppercase">{r.dest_device_name || 'THIS ASSET'}</span>
                      {r.dest_custom_ip && <span className="text-[10px] text-white opacity-60  font-bold">{r.dest_custom_ip}</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className="px-2 py-0.5 rounded-lg bg-black/40 border border-white/10 text-indigo-400 font-bold text-[10px]">
                      {r.protocol} // {r.port_range}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button onClick={() => setConfirmModal({ isOpen: true, id: r.id })} className="p-1.5 hover:bg-rose-500/10 text-slate-500 hover:text-rose-400 rounded-lg transition-all opacity-0 group-hover:opacity-100">
                      <Trash2 size={14}/>
                    </button>
                  </td>
                </tr>
              ))}
              {!rules?.length && (
                <tr><td colSpan={5} className="px-4 py-12 text-center text-slate-600 font-bold uppercase  tracking-widest bg-black/5">No active firewall exceptions for this asset</td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      <ConfirmationModal 
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, id: null })}
        onConfirm={() => deleteMutation.mutate(confirmModal.id)}
        title="Revoke Security Policy"
        message="Are you sure you want to revoke this firewall exception? This may cause immediate service disruption."
        variant="danger"
      />
    </div>
  )
}

const MonitoringTab = ({ deviceId }: { deviceId: number }) => {
  const { data: items, isLoading } = useQuery({
    queryKey: ['device-monitoring', deviceId],
    queryFn: async () => (await apiFetch(`/api/v1/monitoring?device_id=${deviceId}`)).json()
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-2">
         <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-blue-600 pl-3">Active Monitoring Logic</h3>
      </div>
      
      {isLoading ? (
        <div className="py-20 text-center text-slate-500"><RefreshCcw className="animate-spin mx-auto mb-4" /> <span className="text-[10px] font-bold uppercase tracking-widest">Scanning Logic Matrix...</span></div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {items?.map((item: any) => (
            <div key={item.id} className="bg-white/5 border border-white/10 rounded-lg p-6 hover:border-blue-500/30 transition-all group">
              <div className="flex items-start justify-between mb-6">
                 <div className="flex items-center space-x-4">
                    <div className="p-3 bg-blue-600/10 rounded-lg text-blue-400 border border-blue-500/20">
                       <Activity size={20} />
                    </div>
                    <div>
                       <h4 className="text-sm font-bold text-white uppercase tracking-tight">{item.title}</h4>
                       <div className="flex items-center space-x-3 mt-1">
                          <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{item.category} // {item.platform}</span>
                          <span className={`px-2 py-0.5 rounded-lg text-[8px] font-bold uppercase tracking-widest border ${
                             item.status === 'Existing' ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5' :
                             'text-blue-400 border-blue-500/20 bg-blue-500/5'
                          }`}>{item.status}</span>
                       </div>
                    </div>
                 </div>
                 {item.monitoring_url && (
                    <button onClick={() => window.open(item.monitoring_url, '_blank')} className="p-2 bg-white/5 rounded-lg text-slate-500 hover:text-blue-400 hover:bg-white/10 transition-all">
                       <ExternalLink size={16} />
                    </button>
                 )}
              </div>

              <div className="space-y-4">
                 {item.logic_json?.length > 0 ? (
                    <div className="bg-black/40 rounded-lg border border-white/5 overflow-hidden">
                       <table className="w-full text-[10px]">
                          <thead className="bg-white/5 border-b border-white/5">
                             <tr>
                                <th className="px-4 py-2 text-left font-bold uppercase text-slate-500">Logic Type</th>
                                <th className="px-4 py-2 text-left font-bold uppercase text-slate-500">Trigger / Description</th>
                                <th className="px-4 py-2 text-left font-bold uppercase text-slate-500">Technical Parameters</th>
                             </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                             {item.logic_json.map((l: any, idx: number) => (
                                <tr key={idx} className="hover:bg-white/5 transition-colors">
                                   <td className="px-4 py-2 font-bold text-blue-400 uppercase">{l.type}</td>
                                   <td className="px-4 py-2 text-slate-300 font-bold">{l.description}</td>
                                   <td className="px-4 py-2 font-mono text-indigo-400">{l.parameters}</td>
                                </tr>
                             ))}
                          </tbody>
                       </table>
                    </div>
                 ) : (
                    <div className="p-4 bg-black/20 rounded-lg border border-dashed border-white/10 text-center">
                       <p className="text-[9px] font-bold text-slate-600 uppercase ">No structured logic entries defined</p>
                    </div>
                 )}

                 <div className="flex items-start justify-between pt-2 border-t border-white/5">
                    <div className="space-y-1">
                       <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Notification Path</p>
                       <p className="text-[10px] font-bold text-slate-400 uppercase">{item.notification_method} // {item.notification_recipients?.join(', ') || 'Global NOC'}</p>
                    </div>
                    <div className="text-right">
                       <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Owner / Point of Contact</p>
                       <p className="text-[10px] font-bold text-slate-400 uppercase">{item.owner || 'System Engineering'}</p>
                    </div>
                 </div>
              </div>
            </div>
          ))}
          {!items?.length && (
            <div className="py-20 text-center border-2 border-dashed border-white/5 rounded-lg flex flex-col items-center justify-center space-y-4">
               <div className="p-6 bg-white/5 rounded-lg opacity-20"><Activity size={48} /></div>
               <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-slate-600 ">No monitoring logic bound to this asset</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}


const HWTab = ({ deviceId }: { deviceId: number }) => {
  const queryClient = useQueryClient()
  const [newComp, setNewComp] = useState({ category: 'CPU', name: '', manufacturer: '', specs: '', count: 1 })

  const mutation = useMutation({
    mutationFn: async (d: any) => {
      const res = await apiFetch(`/api/v1/devices/${deviceId}/hardware`, { method: 'POST', body: JSON.stringify(d) })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-hw', deviceId] }); setNewComp({ category: 'CPU', name: '', manufacturer: '', specs: '', count: 1 }) }
  })

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-6 gap-2 bg-white/5 p-3 rounded-lg border border-white/5">
         <select value={newComp.category} onChange={e => setNewComp({...newComp, category: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-[10px] outline-none">
            <option>CPU</option><option>Memory</option><option>Card</option><option>Disk</option><option>NIC</option><option>PSU</option>
         </select>
         <input value={newComp.name} onChange={e => setNewComp({...newComp, name: e.target.value})} placeholder="Component Name" className="bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-[10px] outline-none" />
         <input value={newComp.manufacturer} onChange={e => setNewComp({...newComp, manufacturer: e.target.value})} placeholder="Manufacturer" className="bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-[10px] outline-none" />
         <input value={newComp.specs} onChange={e => setNewComp({...newComp, specs: e.target.value})} placeholder="Specifications" className="bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-[10px] outline-none" />
         <input type="number" value={newComp.count} onChange={e => setNewComp({...newComp, count: parseInt(e.target.value)})} className="bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-[10px] outline-none" />
         <button onClick={() => { if(!newComp.name) return toast.error("Name required"); mutation.mutate(newComp) }} className="bg-blue-600 text-white rounded-lg text-[9px] font-bold uppercase">Add</button>
      </div>
      <HWTable deviceId={deviceId} />
    </div>
  )
}

const HWTable = ({ deviceId }: { deviceId: number }) => {
  const queryClient = useQueryClient()
  const { data: hardware } = useQuery({ queryKey: ['device-hw', deviceId], queryFn: async () => (await (await apiFetch(`/api/v1/devices/${deviceId}/hardware`)).json()) })
  const [editingId, setEditingId] = useState<number | null>(null)
  const [editData, setEditData] = useState<any>(null)
  const [confirmModal, setConfirmModal] = useState<any>({ isOpen: false, title: '', message: '', onConfirm: () => {} })
  
  const delMutation = useMutation({
    mutationFn: async (id: number) => apiFetch(`/api/v1/devices/hardware/${id}`, { method: 'DELETE' }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-hw', deviceId] }); toast.success('Component removed') },
    onError: (e: any) => toast.error(e.message || 'Failed to delete component')
  })

  const updateMutation = useMutation({
    mutationFn: async (data: any) => apiFetch(`/api/v1/devices/hardware/${data.id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
    }),
    onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['device-hw', deviceId] })
        setEditingId(null)
        toast.success('Component Updated')
    },
    onError: (e: any) => toast.error(e.message || 'Failed to update component')
  })

  const catOptions = [
    { value: 'CPU', label: 'CPU' },
    { value: 'Memory', label: 'Memory' },
    { value: 'Card', label: 'Card' },
    { value: 'Disk', label: 'Disk' },
    { value: 'NIC', label: 'NIC' },
    { value: 'PSU', label: 'PSU' }
  ]

  return (
    <div className="p-0">
      <table className="w-full text-[10px]">
        <thead className="bg-white/5 border-b border-white/5">
          <tr>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Category</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Component</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Specs</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Qty</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {hardware?.map((h: any) => (
            <tr key={h.id} className="hover:bg-white/5 transition-colors">
              <td className="px-4 py-2 text-center">
                {editingId === h.id ? (
                    <StyledSelect
                        value={editData.category}
                        onChange={e => setEditData({...editData, category: e.target.value})}
                        options={catOptions}
                        className="w-24 mx-auto"
                    />
                ) : (
                    <span className="text-[10px] font-bold uppercase text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-lg">{h.category}</span>
                )}
              </td>
              <td className="px-4 py-2 font-bold text-slate-200 text-center text-[10px]">
                {editingId === h.id ? (
                    <input value={editData.name} onChange={e => setEditData({...editData, name: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-[10px] w-full outline-none focus:border-blue-500" />
                ) : h.name}
              </td>
              <td className="px-4 py-2 text-slate-500 text-center font-bold text-[10px]">
                {editingId === h.id ? (
                    <input value={editData.specs} onChange={e => setEditData({...editData, specs: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-[10px] w-full outline-none focus:border-blue-500" />
                ) : h.specs}
              </td>
              <td className="px-4 py-2 text-center text-slate-400 font-bold text-[10px]">
                {editingId === h.id ? (
                    <input type="number" value={editData.count} onChange={e => setEditData({...editData, count: parseInt(e.target.value)})} className="bg-slate-900 border border-white/10 rounded-lg px-1 py-1.5 text-[10px] w-12 outline-none focus:border-blue-500" />
                ) : `x${h.count}`}
              </td>
              <td className="px-4 py-2 text-center">
                {editingId === h.id ? (
                    <div className="flex items-center justify-center space-x-1">
                        <button onClick={() => updateMutation.mutate(editData)} className="p-1.5 hover:bg-emerald-500/20 text-emerald-400 rounded-lg"><Check size={14}/></button>
                        <button onClick={() => setEditingId(null)} className="p-1.5 hover:bg-rose-500/20 text-rose-400 rounded-lg"><X size={14}/></button>
                    </div>
                ) : (
                    <div className="flex items-center justify-center space-x-1">
                        <button onClick={() => { setEditingId(h.id); setEditData({...h}); }} className="p-1.5 hover:bg-white/10 text-slate-500 hover:text-blue-400 rounded-lg transition-all"><Edit2 size={14}/></button>
                        <button onClick={() => setConfirmModal({ isOpen: true, title: 'Purge Component', message: 'Purge this hardware component?', onConfirm: () => delMutation.mutate(h.id) })} className="p-1.5 hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 rounded-lg transition-all"><Trash2 size={14}/></button>
                    </div>
                )}
              </td>
            </tr>
          ))}
          {!hardware?.length && <tr><td colSpan={8}><WorkspaceEmptyState compact title="No hardware mappings found" /></td></tr>}
        </tbody>
      </table>
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({...confirmModal, isOpen: false})}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant="danger"
      />
    </div>
  )
}

const SecretsTab = ({ deviceId }: { deviceId: number }) => {
  const queryClient = useQueryClient()
  const [newSec, setNewSec] = useState({ secret_type: 'Root Password', username: '', encrypted_payload: '', notes: '' })

  const mutation = useMutation({
    mutationFn: async (d: any) => {
      const res = await apiFetch(`/api/v1/devices/${deviceId}/secrets`, { method: 'POST', body: JSON.stringify(d) })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-secrets', deviceId] }); setNewSec({ secret_type: 'Root Password', username: '', encrypted_payload: '', notes: '' }); toast.success('Credential added') }
  })

  const secOptions = [
    { value: 'Root Password', label: 'Root Password' },
    { value: 'Admin API Key', label: 'Admin API Key' },
    { value: 'Service Account', label: 'Service Account' },
    { value: 'SSH Key', label: 'SSH Key' },
    { value: 'ILO/IDRAC', label: 'ILO/IDRAC' }
  ]

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-5 gap-2 bg-white/5 p-3 rounded-lg border border-white/5 items-end">
         <div className="col-span-1">
           <StyledSelect
              value={newSec.secret_type}
              onChange={e => setNewSec({...newSec, secret_type: e.target.value})}
              options={secOptions}
              label="Secret Type"
           />
         </div>
         <div className="col-span-1">
            <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1 px-1">Identity</label>
            <input value={newSec.username} onChange={e => setNewSec({...newSec, username: e.target.value})} placeholder="Identity / Username" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
         </div>
         <div className="col-span-1">
            <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1 px-1">Sensitive Value</label>
            <input type="password" value={newSec.encrypted_payload} onChange={e => setNewSec({...newSec, encrypted_payload: e.target.value})} placeholder="Value" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
         </div>
         <div className="col-span-1">
            <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1 px-1">Notes</label>
            <input value={newSec.notes} onChange={e => setNewSec({...newSec, notes: e.target.value})} placeholder="Purpose / Note" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
         </div>
         <button onClick={() => { if(!newSec.username || !newSec.encrypted_payload) return toast.error("Identity/Value required"); mutation.mutate(newSec) }} className="h-[38px] bg-emerald-600 text-white rounded-lg text-[9px] font-bold uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">Add</button>
      </div>
      <SecretsTable deviceId={deviceId} />
    </div>
  )
}

const SecretsTable = ({ deviceId }: { deviceId: number }) => {
  const queryClient = useQueryClient()
  const { data: secrets } = useQuery({ queryKey: ['device-secrets', deviceId], queryFn: async () => (await (await apiFetch(`/api/v1/devices/${deviceId}/secrets`)).json()) })
  const [editingId, setEditingId] = useState<number | null>(null)
  const [editData, setEditData] = useState<any>(null)
  const [visibleIds, setVisibleIds] = useState<number[]>([])
  const [confirmModal, setConfirmModal] = useState<any>({ isOpen: false, title: '', message: '', onConfirm: () => {} })

  const toggleVisibility = (id: number) => {
    setVisibleIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }

  const delMutation = useMutation({
    mutationFn: async (id: number) => apiFetch(`/api/v1/devices/secrets/${id}`, { method: 'DELETE' }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-secrets', deviceId] }); toast.success('Credential removed') },
    onError: (e: any) => toast.error(e.message || 'Failed to delete credential')
  })

  const updateMutation = useMutation({
    mutationFn: async (data: any) => apiFetch(`/api/v1/devices/secrets/${data.id}`, {
        method: 'PUT', body: JSON.stringify(data)
    }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-secrets', deviceId] }); setEditingId(null); toast.success('Credential updated') },
    onError: (e: any) => toast.error(e.message || 'Failed to update credential')
  })

  const secOptions = [
    { value: 'Root Password', label: 'Root Password' },
    { value: 'Admin API Key', label: 'Admin API Key' },
    { value: 'Service Account', label: 'Service Account' },
    { value: 'SSH Key', label: 'SSH Key' },
    { value: 'ILO/IDRAC', label: 'ILO/IDRAC' }
  ]

  return (
    <div className="p-0">
      <table className="w-full text-[10px]">
        <thead className="bg-white/5 border-b border-white/5">
          <tr>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Type</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Identity</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Payload</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Notes</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {secrets?.map((s: any) => (
            <tr key={s.id} className="hover:bg-white/5 transition-colors">
              <td className="px-4 py-2 font-bold uppercase text-amber-500/80">
                {editingId === s.id ? (
                    <StyledSelect
                        value={editData.secret_type}
                        onChange={e => setEditData({...editData, secret_type: e.target.value})}
                        options={secOptions}
                        className="w-32"
                    />
                ) : s.secret_type}
              </td>
              <td className="px-4 py-2 font-bold text-slate-200">
                {editingId === s.id ? (
                    <input value={editData.username} onChange={e => setEditData({...editData, username: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-[10px] w-full outline-none focus:border-blue-500" />
                ) : s.username}
              </td>
              <td className="px-4 py-2 text-slate-400">
                {editingId === s.id ? (
                    <input type="password" value={editData.encrypted_payload} onChange={e => setEditData({...editData, encrypted_payload: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-[10px] w-full outline-none focus:border-blue-500" placeholder="Update secret..." />
                ) : (
                    <div className="flex items-center space-x-3 group">
                       <span className={visibleIds.includes(s.id) ? 'text-blue-300' : 'text-slate-700'}>{visibleIds.includes(s.id) ? s.encrypted_payload : '••••••••••••'}</span>
                       <button onClick={() => toggleVisibility(s.id)} className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-500 hover:text-blue-400">
                          {visibleIds.includes(s.id) ? <EyeOff size={14}/> : <Eye size={14}/>}
                       </button>
                    </div>
                )}
              </td>
              <td className="px-4 py-2 text-slate-500">
                {editingId === s.id ? (
                    <input value={editData.notes} onChange={e => setEditData({...editData, notes: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1.5 text-[10px] w-full outline-none focus:border-blue-500" />
                ) : s.notes}
              </td>
              <td className="px-4 py-2 text-center">
                {editingId === s.id ? (
                    <div className="flex items-center justify-center space-x-1">
                        <button onClick={() => updateMutation.mutate(editData)} className="p-1.5 hover:bg-emerald-500/20 text-emerald-400 rounded-lg"><Check size={14}/></button>
                        <button onClick={() => setEditingId(null)} className="p-1.5 hover:bg-rose-500/20 text-rose-400 rounded-lg"><X size={14}/></button>
                    </div>
                ) : (
                    <div className="flex items-center justify-center space-x-1">
                        <button onClick={() => { setEditingId(s.id); setEditData({...s}); }} className="p-1.5 hover:bg-white/10 text-slate-500 hover:text-blue-400 rounded-lg transition-all"><Edit2 size={14}/></button>
                        <button onClick={() => setConfirmModal({ isOpen: true, title: 'Delete Credential', message: 'Remove this credential?', onConfirm: () => delMutation.mutate(s.id) })} className="p-1.5 hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 rounded-lg transition-all"><Trash2 size={14}/></button>
                    </div>
                )}
              </td>
            </tr>
          ))}
          {!secrets?.length && <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-600 font-bold uppercase ">No credentials stored</td></tr>}
        </tbody>
      </table>
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({...confirmModal, isOpen: false})}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant="danger"
      />
    </div>
  )
}

const RelationshipsTab = ({ deviceId }: { deviceId: number }) => {
  const queryClient = useQueryClient()
  const { data: devices } = useQuery({ queryKey: ['devices'], queryFn: async () => (await (await apiFetch('/api/v1/devices')).json()) })
  
  const types = useMemo(() => [
    { label: 'Depends On', s: 'Consumer', t: 'Provider' },
    { label: 'Hosts', s: 'Hypervisor', t: 'Guest' },
    { label: 'Backs Up', s: 'Source', t: 'Target' },
    { label: 'Replicates to', s: 'Primary', t: 'Replica' },
    { label: 'Cluster Member', s: 'Node', t: 'Peer' }
  ], [])

  const currentDevice = useMemo(() => devices?.find((d: any) => d.id === deviceId), [devices, deviceId]);

  const [newRel, setNewRel] = useState({ 
    target_device_id: '', 
    relationship_type: 'Depends On', 
    source_role: 'Consumer', 
    target_role: 'Provider' 
  })

  const mutation = useMutation({
    mutationFn: async (d: any) => {
      const res = await apiFetch(`/api/v1/devices/${deviceId}/relationships`, {
        method: 'POST',
        body: JSON.stringify(d)
      })
      if (!res.ok) throw new Error(await res.text())
      return res.json()
    },
    onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['device-rel', deviceId] });
        toast.success('Relationship added')
    }
  })

  const syncRoles = (role: string, isSource: boolean) => {
    const pair = types.find(t => t.s === role || t.t === role);
    if (pair) {
        if (isSource) {
            const targetRole = role === pair.s ? pair.t : pair.s;
            setNewRel(prev => ({ ...prev, source_role: role, target_role: targetRole, relationship_type: pair.label }));
        } else {
            const sourceRole = role === pair.s ? pair.t : pair.s;
            setNewRel(prev => ({ ...prev, target_role: role, source_role: sourceRole, relationship_type: pair.label }));
        }
    }
  }

  const swapRoles = () => {
    setNewRel(prev => ({
        ...prev,
        source_role: prev.target_role,
        target_role: prev.source_role
    }));
  }

  const allRoles = useMemo(() => {
    const roles = new Set<string>();
    types.forEach(t => { roles.add(t.s); roles.add(t.t); });
    return Array.from(roles).map(r => ({ value: r, label: r }));
  }, [types]);

  return (
    <div className="space-y-6">
      <div className="bg-white/5 p-6 rounded-lg border border-white/5 space-y-6">
         <div className="grid grid-cols-11 gap-4 items-end">
            <div className="col-span-3">
               <label className="text-[9px] font-bold text-slate-500 uppercase block mb-2 px-1">Local Asset (A)</label>
               <div className="w-full bg-blue-600/10 border border-blue-500/20 rounded-lg px-4 py-2.5 text-xs text-blue-400 font-bold uppercase truncate">
                  {currentDevice?.name || 'Local'}
               </div>
            </div>

            <div className="col-span-2">
               <StyledSelect
                  label="Role (A)"
                  value={newRel.source_role}
                  onChange={e => syncRoles(e.target.value, true)}
                  options={allRoles}
               />
            </div>

            <div className="col-span-1 flex justify-center pb-2">
               <button 
                 onClick={swapRoles}
                 className="p-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-slate-400 hover:text-white transition-all group"
                 title="Swap Roles"
               >
                  <ArrowRightLeft size={16} className="group-active:rotate-180 transition-transform duration-300" />
               </button>
            </div>

            <div className="col-span-2">
               <StyledSelect
                  label="Role (B)"
                  value={newRel.target_role}
                  onChange={e => syncRoles(e.target.value, false)}
                  options={allRoles}
               />
            </div>

            <div className="col-span-3">
               <StyledSelect
                  value={newRel.target_device_id}
                  onChange={e => setNewRel({...newRel, target_device_id: e.target.value})}
                  options={devices?.filter((d:any)=> d.id !== deviceId).map((d:any)=>({ value: String(d.id), label: `${d.name} [${d.type}]` })) || []}
                  label="Peer Asset (B)"
                  placeholder="Select Peer..."
               />
            </div>
         </div>

         <div className="flex items-center justify-between pt-2 border-t border-white/5">
            <div className="flex items-center space-x-2">
               <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Vector Classification:</span>
               <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest bg-indigo-500/10 px-2 py-0.5 rounded-lg border border-indigo-500/20">{newRel.relationship_type}</span>
            </div>
            <button 
              onClick={() => { if(!newRel.target_device_id) return toast.error("Select peer asset"); mutation.mutate(newRel) }} 
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-[9px] font-bold uppercase tracking-widest shadow-lg shadow-indigo-500/20 active:scale-95 transition-all flex items-center space-x-2"
            >
               <Plus size={14} /> <span>Establish Vector</span>
            </button>
         </div>
      </div>
      <RelationsTable deviceId={deviceId} />
    </div>
  )
}

const RelationsTable = ({ deviceId }: { deviceId: number }) => {
  const queryClient = useQueryClient()
  const { data: relationships } = useQuery({ queryKey: ['device-rel', deviceId], queryFn: async () => (await (await apiFetch(`/api/v1/devices/${deviceId}/relationships`)).json()) })
  const { data: devices } = useQuery({ queryKey: ['devices'], queryFn: async () => (await (await apiFetch('/api/v1/devices')).json()) })
  const [confirmModal, setConfirmModal] = useState<any>({ isOpen: false, title: '', message: '', onConfirm: () => {} })
  const [editingId, setEditingId] = useState<number | null>(null)
  const [editData, setEditData] = useState<any>(null)

  const currentDevice = useMemo(() => devices?.find((d: any) => d.id === deviceId), [devices, deviceId]);

  const delMutation = useMutation({
    mutationFn: async (id: number) => apiFetch(`/api/v1/devices/relationships/${id}`, { method: 'DELETE' }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-rel', deviceId] }); toast.success('Relationship removed') },
    onError: (e: any) => toast.error(e.message || 'Failed to delete relationship')
  })

  const updateMutation = useMutation({
    mutationFn: async (data: any) => apiFetch(`/api/v1/devices/relationships/${data.id}`, {
        method: 'PUT', body: JSON.stringify(data)
    }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['device-rel', deviceId] }); setEditingId(null); toast.success('Relationship updated') },
    onError: (e: any) => toast.error(e.message || 'Failed to update relationship')
  })

  return (
    <div className="p-0">
      <table className="w-full text-[10px]">
        <thead className="bg-white/5 border-b border-white/5">
          <tr>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Local Identity</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Relationship Type</th>
            <th className="px-4 py-2 text-left font-bold uppercase tracking-widest text-slate-500">Peer Entity</th>
            <th className="px-4 py-2 text-center font-bold uppercase tracking-widest text-slate-500">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {relationships?.map((r: any) => {
            const isSource = r.source_device_id === deviceId;
            const peerId = isSource ? r.target_device_id : r.source_device_id;
            const peer = devices?.find((d:any) => d.id === peerId);
            const localRole = isSource ? r.source_role : r.target_role;
            const peerRole = isSource ? r.target_role : r.source_role;

            return (
              <tr key={r.id} className="hover:bg-white/5 transition-colors">
                <td className="px-4 py-3">
                   {editingId === r.id ? (
                     <select value={isSource ? editData.source_role : editData.target_role} onChange={e => isSource ? setEditData({...editData, source_role: e.target.value}) : setEditData({...editData, target_role: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1 text-[10px] w-full outline-none focus:border-blue-500">
                       <option>Consumer</option>
                       <option>Provider</option>
                       <option>Hypervisor</option>
                       <option>Guest</option>
                       <option>Source</option>
                       <option>Target</option>
                       <option>Primary</option>
                       <option>Replica</option>
                       <option>Node</option>
                       <option>Peer</option>
                     </select>
                   ) : (
                     <div className="flex flex-col">
                        <span className="font-bold text-white uppercase tracking-tight text-[10px]">{currentDevice?.name || 'Local'}</span>
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-lg w-fit mt-1 ${isSource ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-500/10 text-slate-400 border border-slate-500/20'}`}>
                          {localRole}
                        </span>
                     </div>
                   )}
                </td>
                <td className="px-4 py-3 text-center">
                  {editingId === r.id ? (
                    <select value={editData.relationship_type} onChange={e => setEditData({...editData, relationship_type: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1 text-[10px] w-full outline-none focus:border-blue-500">
                      <option>Depends On</option>
                      <option>Hosts</option>
                      <option>Backs Up</option>
                      <option>Replicates to</option>
                      <option>Cluster Member</option>
                    </select>
                  ) : (
                    <div className="flex flex-col items-center">
                       <span className="font-bold text-slate-500 uppercase tracking-widest text-[10px] mb-1">{r.relationship_type}</span>
                       <div className="flex items-center space-x-2 text-slate-600">
                          <div className="h-px w-8 bg-white/10" />
                          <ArrowRightLeft size={10} className={isSource ? "" : "rotate-180"} />
                          <div className="h-px w-8 bg-white/10" />
                       </div>
                    </div>
                  )}
                </td>
                <td className="px-4 py-3">
                    {editingId === r.id ? (
                      <select value={!isSource ? editData.source_role : editData.target_role} onChange={e => !isSource ? setEditData({...editData, source_role: e.target.value}) : setEditData({...editData, target_role: e.target.value})} className="bg-slate-900 border border-white/10 rounded-lg px-2 py-1 text-[10px] w-full outline-none focus:border-blue-500">
                        <option>Consumer</option>
                        <option>Provider</option>
                        <option>Hypervisor</option>
                        <option>Guest</option>
                        <option>Source</option>
                        <option>Target</option>
                        <option>Primary</option>
                        <option>Replica</option>
                        <option>Node</option>
                        <option>Peer</option>
                      </select>
                    ) : (
                      <div className="flex flex-col">
                         <span className="font-bold text-blue-400 uppercase tracking-tight text-[10px]">{peer?.name || 'Unknown Entity'}</span>
                         <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-lg w-fit mt-1 ${!isSource ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-500/10 text-slate-400 border border-slate-500/20'}`}>
                           {peerRole}
                         </span>
                      </div>
                    )}
                </td>
                <td className="px-4 py-3 text-center">
                  {editingId === r.id ? (
                    <div className="flex items-center justify-center space-x-1">
                      <button onClick={() => updateMutation.mutate(editData)} className="p-1.5 hover:bg-emerald-500/20 text-emerald-400 rounded-lg transition-all"><Check size={14}/></button>
                      <button onClick={() => setEditingId(null)} className="p-1.5 hover:bg-slate-500/20 text-slate-500 rounded-lg transition-all"><X size={14}/></button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center space-x-1">
                      <button onClick={() => { setEditingId(r.id); setEditData({...r}) }} className="p-1.5 hover:bg-blue-500/20 text-slate-500 hover:text-blue-400 rounded-lg transition-all"><Edit2 size={14}/></button>
                      <button onClick={() => setConfirmModal({ isOpen: true, title: 'Delete Relationship', message: 'Remove this relationship?', onConfirm: () => delMutation.mutate(r.id) })} className="p-1.5 hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 rounded-lg transition-all"><Trash2 size={14}/></button>
                    </div>
                  )}
                </td>
              </tr>
            )
          })}
          {!relationships?.length && <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-600 font-bold uppercase ">No relationships defined</td></tr>}
        </tbody>
      </table>
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({...confirmModal, isOpen: false})}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        variant="danger"
      />
    </div>
  )
}

const ASSET_TYPES = [
    { value: 'Physical', label: 'Physical' },
    { value: 'Virtual', label: 'Virtual' },
    { value: 'Storage', label: 'Storage' },
    { value: 'Switch', label: 'Switch' },
    { value: 'Firewall', label: 'Firewall' },
    { value: 'Load Balancer', label: 'Load Balancer' },
    { value: 'PDU', label: 'PDU' },
    { value: 'UPS', label: 'UPS' },
    { value: 'Console-Server', label: 'Console Server' },
    { value: 'Patch Panel', label: 'Patch Panel' }
]

const STATUS_ITEMS = [
    { value: 'Planned', label: 'Planned' },
    { value: 'Active', label: 'Active' },
    { value: 'Maintenance', label: 'Maintenance' },
    { value: 'Standby', label: 'Standby' },
    { value: 'Failed', label: 'Failed' },
    { value: 'Decommissioned', label: 'Decommissioned' },
    { value: 'Provisioning', label: 'Provisioning' },
    { value: 'Reserved', label: 'Reserved' }
]

const ENVIRONMENT_ITEMS = [
    { value: 'Production', label: 'Production' },
    { value: 'Staging', label: 'Staging' },
    { value: 'QA', label: 'QA' },
    { value: 'Dev', label: 'Dev' },
    { value: 'DR', label: 'DR' },
    { value: 'Lab', label: 'Lab' },
    { value: 'Sandbox', label: 'Sandbox' },
    { value: 'Legacy', label: 'Legacy' }
]

const AssetForm = ({ initialData, onSave, options, isSaving, devices }: any) => {
  const [activeSubTab, setActiveSubTab] = useState('config')
  const [metadataError, setMetadataError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: '', system: '', type: 'Physical', status: 'Active', environment: 'Production',
    owner: '', business_unit: '', manufacturer: '', model: '', serial_number: '', asset_tag: '',
    os_name: '', os_version: '', primary_ip: '', management_ip: '', management_url: '',
    purchase_date: '', install_date: '', warranty_end: '', eol_date: '',
    power_typical_w: 0, power_max_w: 0,
    metadata_json: {}, ...initialData
  })

  // Sync form data when initialData changes
  React.useEffect(() => {
    setFormData({
      name: '', system: '', type: 'Physical', status: 'Active', environment: 'Production',
      owner: '', business_unit: '', manufacturer: '', model: '', serial_number: '', asset_tag: '',
      os_name: '', os_version: '', primary_ip: '', management_ip: '', management_url: '',
      purchase_date: '', install_date: '', warranty_end: '', eol_date: '',
      power_typical_w: 0, power_max_w: 0,
      metadata_json: {}, ...initialData
    })
  }, [JSON.stringify(initialData)])

  const getOptions = (cat: string) => Array.isArray(options) ? options.filter((o: any) => o.category === cat) : []

  return (
    <div className="space-y-6 py-6">
      <div className="flex space-x-1 bg-black/40 p-1 rounded-lg w-fit mb-4">
         {['config', 'hardware', 'secrets', 'relations', 'metadata'].map(t => {
           const isDisabled = !formData.id && ['hardware', 'secrets', 'relations'].includes(t)
           return (
           <button
             key={t}
             onClick={() => !isDisabled && setActiveSubTab(t)}
             disabled={isDisabled}
             title={isDisabled ? 'Save asset first' : ''}
             className={`px-6 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''} ${activeSubTab === t ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
             {t === 'config' ? 'Base Config' : t === 'relations' ? 'Relationships' : t}
           </button>
         )
         })}
      </div>

      {activeSubTab === 'config' && (
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-1 space-y-4">
             <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-blue-600 pl-3">Identity</h3>
             <div>
                <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Hostname</label>
                <input 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})} 
                  className={`w-full bg-slate-900 border ${!formData.name ? 'border-rose-500/50' : 'border-white/10'} rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500 transition-all`} 
                  placeholder="SRV-NAME-01" 
                />
             </div>
             <div>
                <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Asset Role / Description</label>
                <input 
                  value={formData.role || ''} 
                  onChange={e => setFormData({...formData, role: e.target.value})} 
                  className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500 transition-all" 
                  placeholder="Primary ERP Database Node" 
                />
             </div>
             <StyledSelect
                label="Logical System"
                value={formData.system}
                onChange={e => setFormData({...formData, system: e.target.value})}
                options={getOptions('LogicalSystem')}
                placeholder="Select System..."
                error={!formData.system}
             />
             <div className="grid grid-cols-2 gap-2">
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Owner</label>
                    <input value={formData.owner} onChange={e => setFormData({...formData, owner: e.target.value})} placeholder="Owner" className="w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none focus:border-blue-500/50" />
                </div>
                <StyledSelect
                    label="Business Unit"
                    value={formData.business_unit}
                    onChange={e => setFormData({...formData, business_unit: e.target.value})}
                    options={getOptions('BusinessUnit')}
                    placeholder="Select BU..."
                />
             </div>
          </div>

          <div className="col-span-1 space-y-4">
             <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-emerald-600 pl-3">Classification</h3>
             <div className="grid grid-cols-2 gap-2">
                <StyledSelect
                    label="Asset Type"
                    value={formData.type}
                    onChange={e => setFormData({...formData, type: e.target.value})}
                    options={getOptions('DeviceType')}
                />
                <StyledSelect
                    label="Physical Depth"
                    value={formData.depth || 'Full'}
                    onChange={e => setFormData({...formData, depth: e.target.value})}
                    options={[
                        { value: 'Full', label: 'Full Depth' },
                        { value: 'Half', label: 'Half Depth' }
                    ]}
                />
             </div>
             <div className="grid grid-cols-2 gap-2">
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Height (U)</label>
                    <input type="number" value={formData.size_u || 1} onChange={e => setFormData({...formData, size_u: parseInt(e.target.value)})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
                </div>
                <div />
             </div>
             <StyledSelect
                label="Operational Status"
                value={formData.status}
                onChange={e => setFormData({...formData, status: e.target.value})}
                options={STATUS_ITEMS}
             />
             <StyledSelect
                label="Environment"
                value={formData.environment}
                onChange={e => setFormData({...formData, environment: e.target.value})}
                options={ENVIRONMENT_ITEMS}
             />
             <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-indigo-600 pl-3 mt-6">Management & Connectivity</h3>
             <div className="space-y-3">
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">Primary IP Address</label>
                    <input value={formData.primary_ip || ""} onChange={e => setFormData({...formData, primary_ip: e.target.value})} placeholder="e.g. 10.0.0.100" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-blue-500" />
                </div>
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">Management IP Address</label>
                    <input value={formData.management_ip || ""} onChange={e => setFormData({...formData, management_ip: e.target.value})} placeholder="e.g. 10.0.0.50" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-indigo-500" />
                </div>
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">Management URL / Console</label>
                    <input value={formData.management_url || ""} onChange={e => setFormData({...formData, management_url: e.target.value})} placeholder="https://..." className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2.5 text-xs outline-none focus:border-indigo-500" />
                </div>
             </div>

          </div>

          <div className="col-span-1 space-y-4">
             <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-amber-600 pl-3">Software & Hardware</h3>
             <div>
                <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Manufacturer & Model</label>
                <div className="flex space-x-2">
                   <input value={formData.manufacturer} onChange={e => setFormData({...formData, manufacturer: e.target.value})} placeholder="Dell" className="w-1/2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none" />
                   <input value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} placeholder="R740" className="w-1/2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none" />
                </div>
                
                {/* MODEL MASTER: Copy Layout if no template exists or is empty */}
                {formData.model && (
                  <div className="mt-2">
                    {(() => {
                      const modelTemplates = Array.isArray(options) ? options.filter((o: any) => o.category === 'DeviceModel') : []
                      const formalTemplate = modelTemplates.find((t: any) => t.value.toLowerCase().trim() === formData.model.toLowerCase().trim() || t.label.toLowerCase().trim() === formData.model.toLowerCase().trim())
                      
                      const hasDefinitions = !!(formData.metadata_json?.port_definitions || formalTemplate?.metadata_keys?.length)

                      if (!hasDefinitions) {
                        return (
                          <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg animate-in fade-in slide-in-from-top-1 duration-300">
                            <div className="flex items-center justify-between mb-2">
                               <p className="text-[8px] font-black text-amber-400 uppercase tracking-widest flex items-center gap-1">
                                  <Cpu size={10} /> Model Master: Discovery Required
                               </p>
                            </div>
                            <p className="text-[7px] text-slate-500 font-bold uppercase mb-2 leading-tight">No physical topography found for "{formData.model}". Clone from existing asset?</p>
                            <select 
                              className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-[10px] text-slate-300 outline-none focus:border-blue-500"
                              onChange={(e) => {
                                 const sourceId = parseInt(e.target.value)
                                 const sourceAsset = devices?.find((d: any) => d.id === sourceId)
                                 if (sourceAsset) {
                                    const sourceTemplate = modelTemplates.find((t: any) => t.value.toLowerCase().trim() === sourceAsset.model?.toLowerCase().trim() || t.label.toLowerCase().trim() === sourceAsset.model?.toLowerCase().trim())
                                    let keys = sourceTemplate?.metadata_keys || sourceAsset.metadata_json?.port_definitions
                                    
                                    if (keys) {
                                       setFormData({
                                          ...formData,
                                          metadata_json: { ...formData.metadata_json, port_definitions: keys }
                                       })
                                       toast.success(`Port Topography Cloned: ${sourceAsset.name}`)
                                    } else {
                                       toast.error("Selected source has no topography data")
                                    }
                                 }
                              }}
                              value=""
                            >
                               <option value="" disabled>Select Peer Asset to Clone Topography...</option>
                               {devices?.filter((d: any) => (d.model && d.id !== formData.id) && (d.metadata_json?.port_definitions || modelTemplates.find((t:any) => (t.value.toLowerCase() === d.model?.toLowerCase() || t.label.toLowerCase() === d.model?.toLowerCase()) && t.metadata_keys?.length))).map((d: any) => (
                                  <option key={d.id} value={d.id}>{d.name} [{d.model}]</option>
                               ))}
                            </select>
                          </div>
                        )
                      }
                      
                      if (formData.metadata_json?.port_definitions) {
                         return (
                            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-center justify-between">
                               <span className="text-[8px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-1"><Check size={10}/> Topography Mapped</span>
                               <button 
                                 onClick={() => {
                                    const n = {...formData.metadata_json}; delete n.port_definitions;
                                    setFormData({...formData, metadata_json: n});
                                 }}
                                 className="text-[7px] font-bold text-slate-500 hover:text-rose-400 uppercase"
                               >
                                  Reset
                               </button>
                            </div>
                         )
                      }
                      return null
                    })()}
                  </div>
                )}
             </div>
             <div>
                <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Operating System & Version</label>
                <div className="flex space-x-2">
                   <input value={formData.os_name} onChange={e => setFormData({...formData, os_name: e.target.value})} placeholder="Ubuntu" className="w-1/2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none" />
                   <input value={formData.os_version} onChange={e => setFormData({...formData, os_version: e.target.value})} placeholder="24.04 LTS" className="w-1/2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none" />
                </div>
             </div>
             <div>
                <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Serial / Asset Tag</label>
                <div className="flex space-x-2">
                    <input value={formData.serial_number} onChange={e => setFormData({...formData, serial_number: e.target.value})} placeholder="Serial" className="w-1/2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none" />
                    <input value={formData.asset_tag} onChange={e => setFormData({...formData, asset_tag: e.target.value})} placeholder="Asset Tag" className="w-1/2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none" />
                </div>
             </div>
             <div>
                <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Power Consumption (Watts)</label>
                <div className="flex space-x-2">
                    <div className="w-1/2">
                      <input type="number" min={0} step={0.1} value={formData.power_typical_w || 0} onChange={e => setFormData({...formData, power_typical_w: parseFloat(e.target.value) || 0})} placeholder="0" className="w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none font-bold" />
                      <label className="text-[8px] text-slate-500 uppercase mt-0.5 block">Typical</label>
                    </div>
                    <div className="w-1/2">
                      <input type="number" min={0} step={0.1} value={formData.power_max_w || 0} onChange={e => setFormData({...formData, power_max_w: parseFloat(e.target.value) || 0})} placeholder="0" className="w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs outline-none font-bold" />
                      <label className="text-[8px] text-slate-500 uppercase mt-0.5 block">Peak</label>
                    </div>
                </div>
             </div>
             <h3 className="text-[10px] font-bold uppercase text-slate-500 tracking-widest border-l-2 border-emerald-500 pl-3 mt-6">Lifecycle & Logistics</h3>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">Purchase Date</label>
                    <input type="date" value={formData.purchase_date ? formData.purchase_date.split('T')[0] : ""} onChange={e => setFormData({...formData, purchase_date: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-[10px] outline-none" />
                </div>
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">Installation Date</label>
                    <input type="date" value={formData.install_date ? formData.install_date.split('T')[0] : ""} onChange={e => setFormData({...formData, install_date: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-[10px] outline-none border-emerald-500/30" />
                </div>
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">Warranty End</label>
                    <input type="date" value={formData.warranty_end ? formData.warranty_end.split('T')[0] : ""} onChange={e => setFormData({...formData, warranty_end: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-[10px] outline-none border-amber-500/30" />
                </div>
                <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1 px-1">EOL / Retirement</label>
                    <input type="date" value={formData.eol_date ? formData.eol_date.split('T')[0] : ""} onChange={e => setFormData({...formData, eol_date: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-[10px] outline-none border-rose-500/30" />
                </div>
             </div>
          </div>
        </div>
      )}

      {activeSubTab === 'metadata' && (
        <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
           <MetadataEditor 
             value={formData.metadata_json} 
             onChange={v => setFormData({...formData, metadata_json: v})} 
             onError={setMetadataError}
           />
        </div>
      )}

      {activeSubTab === 'hardware' && (formData.id ? <HWTab deviceId={formData.id} /> : <div className="py-20 text-center text-slate-500 font-bold uppercase text-[10px]">Save the asset first to add hardware components</div>)}
      {activeSubTab === 'secrets' && (formData.id ? <SecretsTab deviceId={formData.id} /> : <div className="py-20 text-center text-slate-500 font-bold uppercase text-[10px]">Save the asset first to add credentials</div>)}
      {activeSubTab === 'relations' && (formData.id ? <RelationshipsTab deviceId={formData.id} /> : <div className="py-20 text-center text-slate-500 font-bold uppercase text-[10px]">Save the asset first to add relationships</div>)}

      <div className="flex space-x-4 pt-4 border-t border-white/5">
        <button
          disabled={!!metadataError || isSaving}
          onClick={() => {
            if(!formData.name || !formData.system) return toast.error("Hostname and Logical System are mandatory");
            onSave({ data: formData })
          }}
          className={`flex-1 py-4 ${metadataError || isSaving ? 'bg-slate-700 cursor-not-allowed' : 'bg-blue-600'} text-white rounded-lg text-[11px] font-bold uppercase tracking-[0.2em] shadow-xl shadow-blue-500/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center space-x-2`}
        >
          {isSaving && <RefreshCcw size={14} className="animate-spin" />}
          <span>Save Asset</span>
        </button>
      </div>
    </div>
  )
}

function AssetMap({ assets, connections, relationships, systemsList }: any) {
  const fgRef = React.useRef<any>();
  const [selectedSystems, setSelectedSystems] = useState<string[]>([])
  const [selectedAssetIds, setSelectedAssetIds] = useState<number[]>([])
  const [depth, setDepth] = useState(1)
  const [selectedNode, setSelectedNode] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [showLegend, setShowLegend] = useState(true)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [isTopologyCollapsed, setIsTopologyCollapsed] = useState(false)
  const [hoveredLink, setHoveredLink] = useState<any>(null)

  const hasFilter = selectedSystems.length > 0 || selectedAssetIds.length > 0 || searchTerm.length >= 2

  const graphData = useMemo(() => {
    if (!hasFilter) return { nodes: [], links: [] }

    const nodesMap = new Map<number, any>()
    const linksMap = new Map<string, any>() // Group by source-target-type

    // 1. Initial nodes from filters
    const rootNodes = assets.filter((a: any) => 
      (selectedSystems.includes(a.system)) ||
      (selectedAssetIds.includes(a.id)) ||
      (searchTerm.length >= 2 && a.name.toLowerCase().includes(searchTerm.toLowerCase()))
    )

    const addNodesAndLinks = (currentNodes: any[], currentDepth: number) => {
      if (currentDepth > depth) return
      
      const nextBatch: any[] = []
      
      currentNodes.forEach(node => {
        if (!nodesMap.has(node.id)) {
          nodesMap.set(node.id, { ...node, label: node.name })
        }

        // Process Physical Connections
        connections?.forEach((c: any) => {
          if (c.source_device_id === node.id || c.target_device_id === node.id) {
            const peerId = c.source_device_id === node.id ? c.target_device_id : c.source_device_id
            const peer = assets.find((a: any) => a.id === peerId)
            if (peer) {
              const pairKey = [node.id, peerId].sort().join('-')
              const linkKey = `net-${pairKey}`
              const existing = linksMap.get(linkKey)
              
              const connType = c.link_type || 'Ethernet'
              if (!existing) {
                linksMap.set(linkKey, { 
                  source: c.source_device_id, 
                  target: c.target_device_id, 
                  type: 'network',
                  labels: [connType],
                  count: 1
                })
              } else if (!existing.labels.includes(connType)) {
                existing.labels.push(connType)
                existing.count++
              }

              if (!nodesMap.has(peerId)) {
                const peerData = { ...peer, label: peer.name }
                nodesMap.set(peerId, peerData)
                nextBatch.push(peerData)
              }
            }
          }
        })

        // Process Logical Relationships
        relationships?.forEach((r: any) => {
          if (r.source_device_id === node.id || r.target_device_id === node.id) {
            const peerId = r.source_device_id === node.id ? r.target_device_id : r.source_device_id
            const peer = assets.find((a: any) => a.id === peerId)
            if (peer) {
              const pairKey = [node.id, peerId].sort().join('-')
              const linkKey = `rel-${pairKey}`
              const existing = linksMap.get(linkKey)
              
              const relType = r.relationship_type
              if (!existing) {
                linksMap.set(linkKey, { 
                  source: r.source_device_id, 
                  target: r.target_device_id, 
                  type: 'dependency',
                  labels: [relType],
                  count: 1
                })
              } else if (!existing.labels.includes(relType)) {
                existing.labels.push(relType)
                existing.count++
              }

              if (!nodesMap.has(peerId)) {
                const peerData = { ...peer, label: peer.name }
                nodesMap.set(peerId, peerData)
                nextBatch.push(peerData)
              }
            }
          }
        })
      })

      if (nextBatch.length > 0) addNodesAndLinks(nextBatch, currentDepth + 1)
    }

    addNodesAndLinks(rootNodes, 0)

    // After grouping, handle curvatures for double links between same pair
    const finalLinks = Array.from(linksMap.values())
    const pairLinksCount: Record<string, number> = {}
    
    finalLinks.forEach(link => {
      const pairKey = [
        typeof link.source === 'object' ? link.source.id : link.source,
        typeof link.target === 'object' ? link.target.id : link.target
      ].sort().join('-')
      pairLinksCount[pairKey] = (pairLinksCount[pairKey] || 0) + 1
    })

    finalLinks.forEach(link => {
      const pairKey = [
        typeof link.source === 'object' ? link.source.id : link.source,
        typeof link.target === 'object' ? link.target.id : link.target
      ].sort().join('-')
      
      if (pairLinksCount[pairKey] > 1) {
        link.curvature = link.type === 'network' ? 0.15 : -0.15
      } else {
        link.curvature = 0
      }
    })

    return {
      nodes: Array.from(nodesMap.values()),
      links: finalLinks
    }
  }, [assets, connections, relationships, selectedSystems, selectedAssetIds, depth, searchTerm, hasFilter])

  useEffect(() => {
    if (fgRef.current && hasFilter) {
      fgRef.current.d3Force('link').distance(150);
      fgRef.current.d3Force('charge').strength(-400);
    }
  }, [graphData, hasFilter]);

  return (
    <div className="h-full flex flex-col relative bg-[#020617]">
      {!hasFilter ? (
        <div className="flex-1 flex flex-col items-center justify-center space-y-8 animate-in fade-in duration-1000">
           <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/20 blur-[100px] rounded-lg animate-pulse" />
              <div className="relative bg-slate-900/50 border border-white/10 p-12 rounded-lg backdrop-blur-3xl flex flex-col items-center text-center space-y-6 shadow-2xl">
                 <div className="w-24 h-24 bg-indigo-600/20 rounded-lg flex items-center justify-center border border-indigo-500/30 text-indigo-400 shadow-[0_0_50px_rgba(99,102,241,0.2)]">
                    <Share2 size={48} className="animate-pulse" />
                 </div>
                 <div className="space-y-2">
                    <h2 className="text-4xl font-black uppercase tracking-tighter text-white">Vector <span className="text-indigo-500">Topology</span></h2>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em]">Infrastructure Connectivity Matrix</p>
                 </div>
                 <div className="max-w-md p-6 bg-black/40 rounded-lg border border-white/5">
                    <p className="text-[11px] font-bold text-slate-400 leading-relaxed uppercase tracking-tight">
                       Map rendering is restricted to active search parameters. Please select a system or search for an asset to initiate topological crawl.
                    </p>
                 </div>
                 <div className="flex flex-wrap justify-center gap-2 max-w-lg">
                    {systemsList.slice(0, 10).map((sys: string) => (
                       <button
                         key={sys}
                         onClick={() => setSelectedSystems([sys])}
                         className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-[9px] font-black uppercase text-slate-400 hover:bg-indigo-600 hover:text-white hover:border-indigo-500 transition-all tracking-widest"
                       >
                          {sys}
                       </button>
                    ))}
                 </div>
              </div>
           </div>
        </div>
      ) : (
        <>
          <div className="absolute top-8 left-8 z-20 flex flex-col space-y-4 pointer-events-none">
             <motion.div 
               animate={{ width: isSidebarCollapsed ? 48 : 320, height: isTopologyCollapsed ? 48 : 'auto' }}
               className="glass-panel rounded-lg border border-white/10 shadow-2xl pointer-events-auto overflow-hidden bg-slate-900/80 backdrop-blur-xl relative"
             >
                <div className="absolute top-4 right-4 flex items-center gap-2 z-30">
                   {!isSidebarCollapsed && !isTopologyCollapsed && (
                      <button 
                        onClick={() => setIsTopologyCollapsed(true)}
                        className="text-slate-500 hover:text-white transition-colors"
                        title="Collapse Topology"
                      >
                         <Minimize2 size={16}/>
                      </button>
                   )}
                   <button 
                     onClick={() => {
                        if (isTopologyCollapsed) setIsTopologyCollapsed(false);
                        else setIsSidebarCollapsed(!isSidebarCollapsed);
                     }}
                     className="text-slate-500 hover:text-white transition-colors"
                   >
                      {isTopologyCollapsed ? <Maximize2 size={16}/> : (isSidebarCollapsed ? <Search size={16}/> : <X size={16}/>)}
                   </button>
                </div>

                <div className={`p-6 space-y-6 transition-all duration-300 ${isSidebarCollapsed || isTopologyCollapsed ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
                   <div className="flex items-center justify-between border-b border-white/5 pb-4 pr-10">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                            <Share2 size={16} />
                         </div>
                         <h3 className="text-[10px] font-bold uppercase tracking-widest text-white">Vector Topology</h3>

                      </div>
                   </div>

                   <div className="space-y-5">
                      <div>
                         <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest block mb-2 px-1">Logical Systems</label>
                         <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto custom-scrollbar pr-1">
                            {systemsList.map((sys: string) => (
                               <button
                                  key={sys}
                                  onClick={() => setSelectedSystems(prev => prev.includes(sys) ? prev.filter(s => s !== sys) : [...prev, sys])}
                                  className={`px-3 py-1.5 rounded-lg text-[8px] font-black uppercase transition-all border ${selectedSystems.includes(sys) ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-500/30' : 'bg-white/5 border-white/5 text-slate-500 hover:border-white/20'}`}
                               >
                                  {sys}
                               </button>
                            ))}
                         </div>
                      </div>

                      <div>
                         <div className="flex items-center justify-between mb-2 px-1">
                            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Crawl Depth</label>
                            <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">{depth} HOPS</span>
                         </div>
                         <input 
                           type="range" min="0" max="3" step="1" 
                           value={depth} onChange={e => setDepth(Number(e.target.value))}
                           className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                         />
                         <div className="flex justify-between text-[7px] font-black text-slate-600 uppercase mt-1.5 px-0.5">
                            <span>Source</span>
                            <span>Discovery</span>
                            <span>Global</span>
                            <span>Matrix</span>
                         </div>
                      </div>

                      <div className="relative">
                         <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
                         <input 
                           value={searchTerm} 
                           onChange={e => setSearchTerm(e.target.value)}
                           placeholder="FOCUS SEARCH..." 
                           className="w-full bg-black/40 border border-white/5 rounded-lg pl-9 pr-4 py-3 text-[9px] font-black text-white outline-none focus:border-indigo-500/50 uppercase tracking-widest transition-all" 
                         />
                      </div>
                   </div>

                   <div className="pt-2">
                      <button 
                        onClick={() => { setSelectedSystems([]); setSearchTerm(''); setSelectedAssetIds([]); }}
                        className="w-full py-3 bg-white/5 hover:bg-rose-500/10 border border-white/5 hover:border-rose-500/30 text-[9px] font-black uppercase tracking-widest text-slate-500 hover:text-rose-500 transition-all rounded-lg"
                      >
                         Reset Workspace
                      </button>
                   </div>
                </div>
             </motion.div>

             <AnimatePresence>
               {selectedNode && !isSidebarCollapsed && (
                  <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="glass-panel w-80 p-6 rounded-lg border border-indigo-500/30 shadow-2xl pointer-events-auto space-y-4 bg-slate-900/90 backdrop-blur-xl">
                     <div className="flex items-start justify-between">
                        <div>
                           <div className="flex items-center gap-2 mb-1">
                              <span className="text-[8px] font-black text-indigo-400 uppercase tracking-[0.2em]">{selectedNode.system}</span>
                              <span className="w-1 h-1 rounded-full bg-white/10" />
                              <span className="text-[8px] font-black text-slate-500 uppercase tracking-[0.1em]">{selectedNode.type}</span>
                           </div>
                           <h4 className="text-sm font-black text-white uppercase tracking-tight leading-none">{selectedNode.name}</h4>
                        </div>
                        <button onClick={() => setSelectedNode(null)} className="text-slate-500 hover:text-white p-1 hover:bg-white/5 rounded-lg transition-all"><X size={14}/></button>
                     </div>
                     <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 rounded-lg bg-black/40 border border-white/5">
                           <p className="text-[7px] font-bold text-slate-500 uppercase mb-1">Status</p>
                           <p className={`text-[9px] font-black uppercase ${selectedNode.status === 'Active' ? 'text-emerald-400' : 'text-amber-500'}`}>{selectedNode.status}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-black/40 border border-white/5">
                           <p className="text-[7px] font-bold text-slate-500 uppercase mb-1">Environment</p>
                           <p className="text-[9px] font-black text-indigo-400 uppercase">{selectedNode.environment}</p>
                        </div>
                     </div>
                     <div className="p-3 rounded-lg bg-black/40 border border-white/5">
                        <p className="text-[7px] font-bold text-slate-500 uppercase mb-1">Primary Network IP</p>
                        <p className="text-[10px] font-mono font-black text-white">{selectedNode.primary_ip || 'DHCP_ASSIGNED'}</p>
                     </div>
                  </motion.div>
               )}
             </AnimatePresence>
          </div>

          <div className={`flex-1 w-full h-full relative transition-opacity duration-500 ${isTopologyCollapsed ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
             <ForceGraph2D
               ref={fgRef}
               graphData={graphData}
               nodeRelSize={6}
               onEngineStop={() => fgRef.current?.zoomToFit(400, 40)}
               nodeCanvasObject={(node: any, ctx, globalScale) => {
                 const label = (node.name || 'UNKNOWN').toUpperCase();
                 const fontSize = 11/globalScale;
                 ctx.font = `700 ${fontSize}px Inter`;
                 
                 const color = node.type === 'Physical' ? '#10b981' : 
                               node.type === 'Virtual' ? '#3b82f6' :
                               node.type === 'Switch' ? '#f43f5e' :
                               node.type === 'Firewall' ? '#f59e0b' :
                               node.type === 'Storage' ? '#8b5cf6' : '#64748b';

                 const textWidth = ctx.measureText(label).width;
                 const padding = fontSize * 0.4;
                 const bckgDimensions = [textWidth + padding, fontSize + padding/2];

                 ctx.fillStyle = 'rgba(2, 6, 23, 0.95)';
                 ctx.fillRect(node.x - bckgDimensions[0] / 2, node.y + 10, bckgDimensions[0], bckgDimensions[1]);

                 ctx.textAlign = 'center';
                 ctx.textBaseline = 'top';
                 ctx.fillStyle = '#f8fafc';
                 ctx.fillText(label, node.x, node.y + 10 + padding/4);

                 ctx.shadowColor = color;
                 ctx.shadowBlur = 15 / globalScale;
                 ctx.beginPath();
                 ctx.arc(node.x, node.y, 6, 0, 2 * Math.PI, false);
                 ctx.fillStyle = color;
                 ctx.fill();
                 
                 if (selectedNode?.id === node.id) {
                    ctx.strokeStyle = '#fff';
                    ctx.lineWidth = 2 / globalScale;
                    ctx.stroke();
                 }
                 ctx.shadowBlur = 0;
               }}
               linkCanvasObjectMode={() => 'after'}
               linkCanvasObject={(link: any, ctx, globalScale) => {
                 const MAX_FONT_SIZE = 8;
                 const start = link.source;
                 const end = link.target;
                 if (typeof start !== 'object' || typeof end !== 'object') return;

                 const countLabel = link.count > 1 ? ` +${link.count - 1}` : '';
                 const text = `${link.labels[0]}${countLabel}`.toUpperCase();
                 
                 const fontSize = Math.min(MAX_FONT_SIZE, 12 / globalScale);
                 ctx.font = `700 ${fontSize}px Inter`;
                 
                 const textWidth = ctx.measureText(text).width;
                 const padding = fontSize * 0.8;
                 const bckgDimensions = [textWidth + padding, fontSize + padding/2];

                 const cp = link.__controlPoints;
                 const textPos = cp 
                    ? { x: cp[0], y: cp[1] }
                    : { x: start.x + (end.x - start.x) * 0.5, y: start.y + (end.y - start.y) * 0.5 };

                 const relLink = { x: end.x - start.x, y: end.y - start.y };
                 let angle = Math.atan2(relLink.y, relLink.x);
                 if (angle > Math.PI / 2 || angle < -Math.PI / 2) angle += Math.PI;

                 ctx.save();
                 ctx.translate(textPos.x, textPos.y);
                 ctx.rotate(angle);
                 
                 ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
                 ctx.fillRect(-bckgDimensions[0] / 2, -bckgDimensions[1] / 2, bckgDimensions[0], bckgDimensions[1]);

                 ctx.textAlign = 'center';
                 ctx.textBaseline = 'middle';
                 ctx.fillStyle = link.type === 'network' ? '#34d399' : '#818cf8';
                 ctx.fillText(text, 0, 0);
                 ctx.restore();
               }}
               linkColor={l => (l as any).type === 'network' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(99, 102, 241, 0.3)'}
               linkWidth={l => (l as any).type === 'network' ? 1 : 2}
               linkDirectionalParticles={l => (l as any).type === 'network' ? 4 : 0}
               linkDirectionalParticleWidth={2}
               linkDirectionalParticleSpeed={0.005}
               linkDirectionalParticleColor={() => '#10b981'}
               linkCurvature={l => (l as any).curvature || 0}
               onNodeClick={node => setSelectedNode(node)}
               onLinkHover={link => setHoveredLink(link)}
               backgroundColor="#020617"
             />
          </div>

          {/* Legend Overlay - Moved to Top Right */}
          <div className={`absolute top-8 right-8 z-20 flex flex-col items-end gap-3 pointer-events-none transition-opacity duration-500 ${isTopologyCollapsed ? 'opacity-0' : 'opacity-100'}`}>
             <AnimatePresence>
               {showLegend && !isTopologyCollapsed && (
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }} 
                    animate={{ opacity: 1, x: 0 }} 
                    exit={{ opacity: 0, x: 20 }}
                    className="glass-panel p-6 rounded-lg border border-white/10 shadow-2xl bg-slate-900/80 backdrop-blur-xl pointer-events-auto w-64"
                  >
                     <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-3">
                        <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-500">Vector Legend</h4>
                        <button onClick={() => setShowLegend(false)} className="text-slate-600 hover:text-white transition-colors"><X size={14}/></button>
                     </div>
                     <div className="space-y-4">
                        <div className="flex flex-col gap-2">
                           <div className="flex items-center gap-3">
                              <div className="w-10 h-0.5 bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
                              <span className="text-[8px] font-black uppercase tracking-widest text-slate-300">Dependency Vector</span>
                           </div>
                           <div className="flex items-center gap-3">
                              <div className="w-10 h-0.5 bg-emerald-500/30 flex items-center justify-center">
                                 <div className="w-1 h-1 rounded-full bg-emerald-400" />
                              </div>
                              <span className="text-[8px] font-black uppercase tracking-widest text-slate-300">Network Fabric</span>
                           </div>
                        </div>
                        <div className="h-px bg-white/5" />
                        <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                           {[
                              { label: 'Physical', color: 'bg-emerald-500' },
                              { label: 'Virtual', color: 'bg-blue-500' },
                              { label: 'Switch', color: 'bg-rose-500' },
                              { label: 'Firewall', color: 'bg-orange-500' },
                              { label: 'Storage', color: 'bg-purple-500' },
                              { label: 'Other', color: 'bg-slate-500' }
                           ].map(type => (
                              <div key={type.label} className="flex items-center gap-2">
                                 <div className={`w-2 h-2 rounded-full ${type.color}`} />
                                 <span className="text-[8px] font-black uppercase tracking-widest text-slate-500">{type.label}</span>
                              </div>
                           ))}
                        </div>
                     </div>
                  </motion.div>
               )}
             </AnimatePresence>

             {/* Link Tooltip for hovered multi-links */}
             <AnimatePresence>
               {hoveredLink && hoveredLink.labels.length > 0 && (
                 <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="glass-panel p-4 rounded-lg border border-blue-500/30 shadow-2xl bg-slate-900/90 backdrop-blur-xl pointer-events-auto min-w-[200px]">
                   <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-2 pb-2 border-b border-white/5">Active Vectors ({hoveredLink.labels.length})</p>
                   <div className="space-y-1.5">
                     {hoveredLink.labels.map((l: string, i: number) => (
                       <div key={i} className="flex items-center gap-2">
                         <div className={`w-1 h-1 rounded-full ${hoveredLink.type === 'network' ? 'bg-emerald-400' : 'bg-indigo-400'}`} />
                         <span className="text-[9px] font-black text-white uppercase tracking-tighter">{l}</span>
                       </div>
                     ))}
                   </div>
                 </motion.div>
               )}
             </AnimatePresence>
          </div>

          <div className={`absolute bottom-8 right-8 flex flex-col gap-3 transition-opacity duration-500 ${isTopologyCollapsed ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
             <div className="glass-panel p-2 rounded-lg border border-white/10 flex flex-col gap-1 bg-slate-900/80 backdrop-blur-xl pointer-events-auto shadow-2xl">
                <button onClick={() => fgRef.current?.zoom(fgRef.current.zoom() * 1.2, 400)} className="p-3 text-slate-500 hover:text-blue-400 hover:bg-white/5 rounded-lg transition-all" title="Zoom In"><ZoomIn size={18}/></button>
                <button onClick={() => fgRef.current?.zoom(fgRef.current.zoom() / 1.2, 400)} className="p-3 text-slate-500 hover:text-blue-400 hover:bg-white/5 rounded-lg transition-all" title="Zoom Out"><ZoomOut size={18}/></button>
                <div className="h-px bg-white/5 mx-1" />
                <button onClick={() => fgRef.current?.zoomToFit(400, 40)} className="p-3 text-slate-500 hover:text-blue-400 hover:bg-white/5 rounded-lg transition-all" title="Reset View"><Maximize2 size={18}/></button>
             </div>
             <button 
               onClick={() => setShowLegend(!showLegend)} 
               className={`p-3 rounded-lg border transition-all shadow-2xl backdrop-blur-xl pointer-events-auto ${showLegend ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-900/80 border-white/10 text-slate-500 hover:text-white'}`}
             >
                <Layers size={18}/>
             </button>
          </div>
        </>
      )}
    </div>
  )
}
